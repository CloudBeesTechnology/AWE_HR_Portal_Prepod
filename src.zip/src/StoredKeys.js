// src/config.js
const apiKey = "HnBNb3SSva9efDAVIQ0256ihdKMTlYBraAbr96Gu";

export { apiKey };
