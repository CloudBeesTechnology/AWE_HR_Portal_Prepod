
export const Logout = () => {
  return (
    <div>Logout</div>
  )
}
