export const EmpDataPass={
      medicalFields : [
        {
          label: "Overseas Medical Fitness issued date",
          name: "overMD",
          type: "date",
        },
        {
          label: "Overseas Medical Fitness Expiry",
          name: "overME",
          type: "date",
        },
        { label: "Upload File", name: "uploadFitness", type: "file" },
        {
          label: "Date submitted of BruHims Registration",
          name: "bruhimsRD",
          type: "date",
        },
        {
          label: "BruHims Registration Number",
          name: "bruhimsRNo",
          type: "text",
        },
        { label: "Upload File", name: "uploadRegis", type: "file" },
        {
          label: "Brunei Medical Appointment Date",
          name: "bruneiMAD",
          type: "date",
        },
        {
          label: "Brunei Medical Fitness Expiry",
          name: "bruneiME",
          type: "date",
        },
        { label: "Upload File", name: "uploadBwn", type: "file" },
      ],
}
   