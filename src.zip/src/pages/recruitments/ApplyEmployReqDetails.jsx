// ApplyEmployReqDetails.jsx
import icon7 from "../../assets/recruitment/recruitdash/apply_employreq.svg";

export const ApplyEmployReqDetails = [
  {
    bg: " shadow-[0_1px_6px_1px_rgba(0,0,0,0.2)]",
    bg1: "bg-[#C9C9C9]",
    icons: icon7,
    title: "Apply Employee Requisition",
    path: "applyemployreq",
  },
];
