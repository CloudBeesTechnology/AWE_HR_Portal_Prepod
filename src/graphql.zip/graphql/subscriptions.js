/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const onCreateApplicantDetails = /* GraphQL */ `
  subscription OnCreateApplicantDetails(
    $filter: ModelSubscriptionApplicantDetailsFilterInput
  ) {
    onCreateApplicantDetails(filter: $filter) {
      id
      empID
      profilePhoto
      agent
      position
      contractType
      name
      chinese
      gender
      age
      email
      countryOfBirth
      nationality
      otherNationality
      marital
      race
      otherRace
      religion
      otherReligion
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onUpdateApplicantDetails = /* GraphQL */ `
  subscription OnUpdateApplicantDetails(
    $filter: ModelSubscriptionApplicantDetailsFilterInput
  ) {
    onUpdateApplicantDetails(filter: $filter) {
      id
      empID
      profilePhoto
      agent
      position
      contractType
      name
      chinese
      gender
      age
      email
      countryOfBirth
      nationality
      otherNationality
      marital
      race
      otherRace
      religion
      otherReligion
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onDeleteApplicantDetails = /* GraphQL */ `
  subscription OnDeleteApplicantDetails(
    $filter: ModelSubscriptionApplicantDetailsFilterInput
  ) {
    onDeleteApplicantDetails(filter: $filter) {
      id
      empID
      profilePhoto
      agent
      position
      contractType
      name
      chinese
      gender
      age
      email
      countryOfBirth
      nationality
      otherNationality
      marital
      race
      otherRace
      religion
      otherReligion
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onCreateEmployeePersonalDoc = /* GraphQL */ `
  subscription OnCreateEmployeePersonalDoc(
    $filter: ModelSubscriptionEmployeePersonalDocFilterInput
  ) {
    onCreateEmployeePersonalDoc(filter: $filter) {
      id
      passportNo
      passportIssued
      passportExpiry
      passportDestination
      contactNo
      address
      employeeBadgeNumber
      sapNumber
      nationalCategory
      countryOfOrigin
      otherCountryOfOrigin
      educationLevel
      academicTechnicalQualification
      nextOfKin
      inductionBriefing
      previousEmployment
      previousEmploymentPeriod
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onUpdateEmployeePersonalDoc = /* GraphQL */ `
  subscription OnUpdateEmployeePersonalDoc(
    $filter: ModelSubscriptionEmployeePersonalDocFilterInput
  ) {
    onUpdateEmployeePersonalDoc(filter: $filter) {
      id
      passportNo
      passportIssued
      passportExpiry
      passportDestination
      contactNo
      address
      employeeBadgeNumber
      sapNumber
      nationalCategory
      countryOfOrigin
      otherCountryOfOrigin
      educationLevel
      academicTechnicalQualification
      nextOfKin
      inductionBriefing
      previousEmployment
      previousEmploymentPeriod
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onDeleteEmployeePersonalDoc = /* GraphQL */ `
  subscription OnDeleteEmployeePersonalDoc(
    $filter: ModelSubscriptionEmployeePersonalDocFilterInput
  ) {
    onDeleteEmployeePersonalDoc(filter: $filter) {
      id
      passportNo
      passportIssued
      passportExpiry
      passportDestination
      contactNo
      address
      employeeBadgeNumber
      sapNumber
      nationalCategory
      countryOfOrigin
      otherCountryOfOrigin
      educationLevel
      academicTechnicalQualification
      nextOfKin
      inductionBriefing
      previousEmployment
      previousEmploymentPeriod
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onCreateEmployeePersonalInfo = /* GraphQL */ `
  subscription OnCreateEmployeePersonalInfo(
    $filter: ModelSubscriptionEmployeePersonalInfoFilterInput
  ) {
    onCreateEmployeePersonalInfo(filter: $filter) {
      id
      empID
      name
      gender
      dateOfBirth
      email
      nationality
      otherNationality
      religion
      marital
      race
      bruneiIcNo
      bruneiIcColour
      bruneiIcExpiry
      malaysianIcNumber
      malaysianIcExpiry
      EmployeePersonalDoc {
        id
        passportNo
        passportIssued
        passportExpiry
        passportDestination
        contactNo
        address
        employeeBadgeNumber
        sapNumber
        nationalCategory
        countryOfOrigin
        otherCountryOfOrigin
        educationLevel
        academicTechnicalQualification
        nextOfKin
        inductionBriefing
        previousEmployment
        previousEmploymentPeriod
        createdAt
        updatedAt
        __typename
      }
      createdAt
      updatedAt
      employeePersonalInfoEmployeePersonalDocId
      __typename
    }
  }
`;
export const onUpdateEmployeePersonalInfo = /* GraphQL */ `
  subscription OnUpdateEmployeePersonalInfo(
    $filter: ModelSubscriptionEmployeePersonalInfoFilterInput
  ) {
    onUpdateEmployeePersonalInfo(filter: $filter) {
      id
      empID
      name
      gender
      dateOfBirth
      email
      nationality
      otherNationality
      religion
      marital
      race
      bruneiIcNo
      bruneiIcColour
      bruneiIcExpiry
      malaysianIcNumber
      malaysianIcExpiry
      EmployeePersonalDoc {
        id
        passportNo
        passportIssued
        passportExpiry
        passportDestination
        contactNo
        address
        employeeBadgeNumber
        sapNumber
        nationalCategory
        countryOfOrigin
        otherCountryOfOrigin
        educationLevel
        academicTechnicalQualification
        nextOfKin
        inductionBriefing
        previousEmployment
        previousEmploymentPeriod
        createdAt
        updatedAt
        __typename
      }
      createdAt
      updatedAt
      employeePersonalInfoEmployeePersonalDocId
      __typename
    }
  }
`;
export const onDeleteEmployeePersonalInfo = /* GraphQL */ `
  subscription OnDeleteEmployeePersonalInfo(
    $filter: ModelSubscriptionEmployeePersonalInfoFilterInput
  ) {
    onDeleteEmployeePersonalInfo(filter: $filter) {
      id
      empID
      name
      gender
      dateOfBirth
      email
      nationality
      otherNationality
      religion
      marital
      race
      bruneiIcNo
      bruneiIcColour
      bruneiIcExpiry
      malaysianIcNumber
      malaysianIcExpiry
      EmployeePersonalDoc {
        id
        passportNo
        passportIssued
        passportExpiry
        passportDestination
        contactNo
        address
        employeeBadgeNumber
        sapNumber
        nationalCategory
        countryOfOrigin
        otherCountryOfOrigin
        educationLevel
        academicTechnicalQualification
        nextOfKin
        inductionBriefing
        previousEmployment
        previousEmploymentPeriod
        createdAt
        updatedAt
        __typename
      }
      createdAt
      updatedAt
      employeePersonalInfoEmployeePersonalDocId
      __typename
    }
  }
`;
export const onCreateLabourDependentPass = /* GraphQL */ `
  subscription OnCreateLabourDependentPass(
    $filter: ModelSubscriptionLabourDependentPassFilterInput
  ) {
    onCreateLabourDependentPass(filter: $filter) {
      id
      passportLocation
      reEntryVisaApplication
      immigrationApprovalDate
      reEntryVisaExpiry
      airTicketStatus
      dependentName
      dependentPassportNumber
      dependentPassportExpiy
      relation
      labourDepositPaidBy
      labourDepositReceiptNumber
      labourDepositAmount
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onUpdateLabourDependentPass = /* GraphQL */ `
  subscription OnUpdateLabourDependentPass(
    $filter: ModelSubscriptionLabourDependentPassFilterInput
  ) {
    onUpdateLabourDependentPass(filter: $filter) {
      id
      passportLocation
      reEntryVisaApplication
      immigrationApprovalDate
      reEntryVisaExpiry
      airTicketStatus
      dependentName
      dependentPassportNumber
      dependentPassportExpiy
      relation
      labourDepositPaidBy
      labourDepositReceiptNumber
      labourDepositAmount
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onDeleteLabourDependentPass = /* GraphQL */ `
  subscription OnDeleteLabourDependentPass(
    $filter: ModelSubscriptionLabourDependentPassFilterInput
  ) {
    onDeleteLabourDependentPass(filter: $filter) {
      id
      passportLocation
      reEntryVisaApplication
      immigrationApprovalDate
      reEntryVisaExpiry
      airTicketStatus
      dependentName
      dependentPassportNumber
      dependentPassportExpiy
      relation
      labourDepositPaidBy
      labourDepositReceiptNumber
      labourDepositAmount
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onCreateLabourMedicalInfo = /* GraphQL */ `
  subscription OnCreateLabourMedicalInfo(
    $filter: ModelSubscriptionLabourMedicalInfoFilterInput
  ) {
    onCreateLabourMedicalInfo(filter: $filter) {
      id
      overseasMedicalDate
      overseasMedicalExpiry
      bruhimsRegistrationDate
      bruhimsRegistrationNumber
      bruneiMedicalAppointmentDate
      bruneiMedicalExpiry
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onUpdateLabourMedicalInfo = /* GraphQL */ `
  subscription OnUpdateLabourMedicalInfo(
    $filter: ModelSubscriptionLabourMedicalInfoFilterInput
  ) {
    onUpdateLabourMedicalInfo(filter: $filter) {
      id
      overseasMedicalDate
      overseasMedicalExpiry
      bruhimsRegistrationDate
      bruhimsRegistrationNumber
      bruneiMedicalAppointmentDate
      bruneiMedicalExpiry
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onDeleteLabourMedicalInfo = /* GraphQL */ `
  subscription OnDeleteLabourMedicalInfo(
    $filter: ModelSubscriptionLabourMedicalInfoFilterInput
  ) {
    onDeleteLabourMedicalInfo(filter: $filter) {
      id
      overseasMedicalDate
      overseasMedicalExpiry
      bruhimsRegistrationDate
      bruhimsRegistrationNumber
      bruneiMedicalAppointmentDate
      bruneiMedicalExpiry
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onCreateLocalMobilization = /* GraphQL */ `
  subscription OnCreateLocalMobilization(
    $filter: ModelSubscriptionLocalMobilizationFilterInput
  ) {
    onCreateLocalMobilization(filter: $filter) {
      id
      tempID
      mobSignDate
      mobFile
      paafApproveDate
      paafFile
      loiIssueDate
      loiAcceptDate
      loiDeclineDate
      declineReason
      loiFile
      cvecApproveDate
      cvecFile
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onUpdateLocalMobilization = /* GraphQL */ `
  subscription OnUpdateLocalMobilization(
    $filter: ModelSubscriptionLocalMobilizationFilterInput
  ) {
    onUpdateLocalMobilization(filter: $filter) {
      id
      tempID
      mobSignDate
      mobFile
      paafApproveDate
      paafFile
      loiIssueDate
      loiAcceptDate
      loiDeclineDate
      declineReason
      loiFile
      cvecApproveDate
      cvecFile
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onDeleteLocalMobilization = /* GraphQL */ `
  subscription OnDeleteLocalMobilization(
    $filter: ModelSubscriptionLocalMobilizationFilterInput
  ) {
    onDeleteLocalMobilization(filter: $filter) {
      id
      tempID
      mobSignDate
      mobFile
      paafApproveDate
      paafFile
      loiIssueDate
      loiAcceptDate
      loiDeclineDate
      declineReason
      loiFile
      cvecApproveDate
      cvecFile
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onCreateLabourWorkPass = /* GraphQL */ `
  subscription OnCreateLabourWorkPass(
    $filter: ModelSubscriptionLabourWorkPassFilterInput
  ) {
    onCreateLabourWorkPass(filter: $filter) {
      id
      empID
      workPermitType
      arrivalStampingExpiry
      employmentPassEndorsement
      immigrationDeptDate
      employmentPassExpiry
      employmentPassStatus
      labourUploadDoc
      remarks
      LabourMedicalInfo {
        id
        overseasMedicalDate
        overseasMedicalExpiry
        bruhimsRegistrationDate
        bruhimsRegistrationNumber
        bruneiMedicalAppointmentDate
        bruneiMedicalExpiry
        createdAt
        updatedAt
        __typename
      }
      LabourDependentPass {
        id
        passportLocation
        reEntryVisaApplication
        immigrationApprovalDate
        reEntryVisaExpiry
        airTicketStatus
        dependentName
        dependentPassportNumber
        dependentPassportExpiy
        relation
        labourDepositPaidBy
        labourDepositReceiptNumber
        labourDepositAmount
        createdAt
        updatedAt
        __typename
      }
      createdAt
      updatedAt
      labourWorkPassLabourMedicalInfoId
      labourWorkPassLabourDependentPassId
      __typename
    }
  }
`;
export const onUpdateLabourWorkPass = /* GraphQL */ `
  subscription OnUpdateLabourWorkPass(
    $filter: ModelSubscriptionLabourWorkPassFilterInput
  ) {
    onUpdateLabourWorkPass(filter: $filter) {
      id
      empID
      workPermitType
      arrivalStampingExpiry
      employmentPassEndorsement
      immigrationDeptDate
      employmentPassExpiry
      employmentPassStatus
      labourUploadDoc
      remarks
      LabourMedicalInfo {
        id
        overseasMedicalDate
        overseasMedicalExpiry
        bruhimsRegistrationDate
        bruhimsRegistrationNumber
        bruneiMedicalAppointmentDate
        bruneiMedicalExpiry
        createdAt
        updatedAt
        __typename
      }
      LabourDependentPass {
        id
        passportLocation
        reEntryVisaApplication
        immigrationApprovalDate
        reEntryVisaExpiry
        airTicketStatus
        dependentName
        dependentPassportNumber
        dependentPassportExpiy
        relation
        labourDepositPaidBy
        labourDepositReceiptNumber
        labourDepositAmount
        createdAt
        updatedAt
        __typename
      }
      createdAt
      updatedAt
      labourWorkPassLabourMedicalInfoId
      labourWorkPassLabourDependentPassId
      __typename
    }
  }
`;
export const onDeleteLabourWorkPass = /* GraphQL */ `
  subscription OnDeleteLabourWorkPass(
    $filter: ModelSubscriptionLabourWorkPassFilterInput
  ) {
    onDeleteLabourWorkPass(filter: $filter) {
      id
      empID
      workPermitType
      arrivalStampingExpiry
      employmentPassEndorsement
      immigrationDeptDate
      employmentPassExpiry
      employmentPassStatus
      labourUploadDoc
      remarks
      LabourMedicalInfo {
        id
        overseasMedicalDate
        overseasMedicalExpiry
        bruhimsRegistrationDate
        bruhimsRegistrationNumber
        bruneiMedicalAppointmentDate
        bruneiMedicalExpiry
        createdAt
        updatedAt
        __typename
      }
      LabourDependentPass {
        id
        passportLocation
        reEntryVisaApplication
        immigrationApprovalDate
        reEntryVisaExpiry
        airTicketStatus
        dependentName
        dependentPassportNumber
        dependentPassportExpiy
        relation
        labourDepositPaidBy
        labourDepositReceiptNumber
        labourDepositAmount
        createdAt
        updatedAt
        __typename
      }
      createdAt
      updatedAt
      labourWorkPassLabourMedicalInfoId
      labourWorkPassLabourDependentPassId
      __typename
    }
  }
`;
export const onCreateLeaveWorkInfo = /* GraphQL */ `
  subscription OnCreateLeaveWorkInfo(
    $filter: ModelSubscriptionLeaveWorkInfoFilterInput
  ) {
    onCreateLeaveWorkInfo(filter: $filter) {
      id
      leavePassageEntitlement
      annualLeaveEntitlement
      annualLeaveEffectDate
      sickLeaveEntitlement
      effectiveDateOfSickLeave
      positionRevision
      revisionSalaryPackage
      leavePassageEntitlementRevision
      effectiveDateOfLeavePassage
      revisionAnnualLeave
      annualEntitlementeffectiveDate
      contractEffectDate
      contractOfEmployee
      remarksWorkInfo
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onUpdateLeaveWorkInfo = /* GraphQL */ `
  subscription OnUpdateLeaveWorkInfo(
    $filter: ModelSubscriptionLeaveWorkInfoFilterInput
  ) {
    onUpdateLeaveWorkInfo(filter: $filter) {
      id
      leavePassageEntitlement
      annualLeaveEntitlement
      annualLeaveEffectDate
      sickLeaveEntitlement
      effectiveDateOfSickLeave
      positionRevision
      revisionSalaryPackage
      leavePassageEntitlementRevision
      effectiveDateOfLeavePassage
      revisionAnnualLeave
      annualEntitlementeffectiveDate
      contractEffectDate
      contractOfEmployee
      remarksWorkInfo
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onDeleteLeaveWorkInfo = /* GraphQL */ `
  subscription OnDeleteLeaveWorkInfo(
    $filter: ModelSubscriptionLeaveWorkInfoFilterInput
  ) {
    onDeleteLeaveWorkInfo(filter: $filter) {
      id
      leavePassageEntitlement
      annualLeaveEntitlement
      annualLeaveEffectDate
      sickLeaveEntitlement
      effectiveDateOfSickLeave
      positionRevision
      revisionSalaryPackage
      leavePassageEntitlementRevision
      effectiveDateOfLeavePassage
      revisionAnnualLeave
      annualEntitlementeffectiveDate
      contractEffectDate
      contractOfEmployee
      remarksWorkInfo
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onCreateTerminationWorkInfo = /* GraphQL */ `
  subscription OnCreateTerminationWorkInfo(
    $filter: ModelSubscriptionTerminationWorkInfoFilterInput
  ) {
    onCreateTerminationWorkInfo(filter: $filter) {
      id
      resignationDate
      terminationDate
      terminationNoticeProbation
      terminationNoticeConfirmation
      resignationNoticeProbation
      resignationNoticeConfirmation
      reasonOfResignation
      reasonOfTermination
      destinationOfEntitlement
      durationPeriodEntitlement
      dateOfEntitlement
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onUpdateTerminationWorkInfo = /* GraphQL */ `
  subscription OnUpdateTerminationWorkInfo(
    $filter: ModelSubscriptionTerminationWorkInfoFilterInput
  ) {
    onUpdateTerminationWorkInfo(filter: $filter) {
      id
      resignationDate
      terminationDate
      terminationNoticeProbation
      terminationNoticeConfirmation
      resignationNoticeProbation
      resignationNoticeConfirmation
      reasonOfResignation
      reasonOfTermination
      destinationOfEntitlement
      durationPeriodEntitlement
      dateOfEntitlement
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onDeleteTerminationWorkInfo = /* GraphQL */ `
  subscription OnDeleteTerminationWorkInfo(
    $filter: ModelSubscriptionTerminationWorkInfoFilterInput
  ) {
    onDeleteTerminationWorkInfo(filter: $filter) {
      id
      resignationDate
      terminationDate
      terminationNoticeProbation
      terminationNoticeConfirmation
      resignationNoticeProbation
      resignationNoticeConfirmation
      reasonOfResignation
      reasonOfTermination
      destinationOfEntitlement
      durationPeriodEntitlement
      dateOfEntitlement
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onCreateEmployeeWorkInfo = /* GraphQL */ `
  subscription OnCreateEmployeeWorkInfo(
    $filter: ModelSubscriptionEmployeeWorkInfoFilterInput
  ) {
    onCreateEmployeeWorkInfo(filter: $filter) {
      id
      empID
      dateOfJoin
      department
      workPosition
      upgradePosition
      jobDescription
      skillPool
      workStatus
      contractStartDate
      contractEndDate
      contractPeriodStatus
      ProbationaryStartDate
      ProbationaryEndDate
      normalWorkingHours
      normalWorkingWeek
      salaryType
      normalWorkingMonth
      employmentWorkStatus
      jobCategory
      otherJobCategory
      upgradeDate
      TerminationWorkInfo {
        id
        resignationDate
        terminationDate
        terminationNoticeProbation
        terminationNoticeConfirmation
        resignationNoticeProbation
        resignationNoticeConfirmation
        reasonOfResignation
        reasonOfTermination
        destinationOfEntitlement
        durationPeriodEntitlement
        dateOfEntitlement
        createdAt
        updatedAt
        __typename
      }
      LeaveWorkInfo {
        id
        leavePassageEntitlement
        annualLeaveEntitlement
        annualLeaveEffectDate
        sickLeaveEntitlement
        effectiveDateOfSickLeave
        positionRevision
        revisionSalaryPackage
        leavePassageEntitlementRevision
        effectiveDateOfLeavePassage
        revisionAnnualLeave
        annualEntitlementeffectiveDate
        contractEffectDate
        contractOfEmployee
        remarksWorkInfo
        createdAt
        updatedAt
        __typename
      }
      createdAt
      updatedAt
      employeeWorkInfoTerminationWorkInfoId
      employeeWorkInfoLeaveWorkInfoId
      __typename
    }
  }
`;
export const onUpdateEmployeeWorkInfo = /* GraphQL */ `
  subscription OnUpdateEmployeeWorkInfo(
    $filter: ModelSubscriptionEmployeeWorkInfoFilterInput
  ) {
    onUpdateEmployeeWorkInfo(filter: $filter) {
      id
      empID
      dateOfJoin
      department
      workPosition
      upgradePosition
      jobDescription
      skillPool
      workStatus
      contractStartDate
      contractEndDate
      contractPeriodStatus
      ProbationaryStartDate
      ProbationaryEndDate
      normalWorkingHours
      normalWorkingWeek
      salaryType
      normalWorkingMonth
      employmentWorkStatus
      jobCategory
      otherJobCategory
      upgradeDate
      TerminationWorkInfo {
        id
        resignationDate
        terminationDate
        terminationNoticeProbation
        terminationNoticeConfirmation
        resignationNoticeProbation
        resignationNoticeConfirmation
        reasonOfResignation
        reasonOfTermination
        destinationOfEntitlement
        durationPeriodEntitlement
        dateOfEntitlement
        createdAt
        updatedAt
        __typename
      }
      LeaveWorkInfo {
        id
        leavePassageEntitlement
        annualLeaveEntitlement
        annualLeaveEffectDate
        sickLeaveEntitlement
        effectiveDateOfSickLeave
        positionRevision
        revisionSalaryPackage
        leavePassageEntitlementRevision
        effectiveDateOfLeavePassage
        revisionAnnualLeave
        annualEntitlementeffectiveDate
        contractEffectDate
        contractOfEmployee
        remarksWorkInfo
        createdAt
        updatedAt
        __typename
      }
      createdAt
      updatedAt
      employeeWorkInfoTerminationWorkInfoId
      employeeWorkInfoLeaveWorkInfoId
      __typename
    }
  }
`;
export const onDeleteEmployeeWorkInfo = /* GraphQL */ `
  subscription OnDeleteEmployeeWorkInfo(
    $filter: ModelSubscriptionEmployeeWorkInfoFilterInput
  ) {
    onDeleteEmployeeWorkInfo(filter: $filter) {
      id
      empID
      dateOfJoin
      department
      workPosition
      upgradePosition
      jobDescription
      skillPool
      workStatus
      contractStartDate
      contractEndDate
      contractPeriodStatus
      ProbationaryStartDate
      ProbationaryEndDate
      normalWorkingHours
      normalWorkingWeek
      salaryType
      normalWorkingMonth
      employmentWorkStatus
      jobCategory
      otherJobCategory
      upgradeDate
      TerminationWorkInfo {
        id
        resignationDate
        terminationDate
        terminationNoticeProbation
        terminationNoticeConfirmation
        resignationNoticeProbation
        resignationNoticeConfirmation
        reasonOfResignation
        reasonOfTermination
        destinationOfEntitlement
        durationPeriodEntitlement
        dateOfEntitlement
        createdAt
        updatedAt
        __typename
      }
      LeaveWorkInfo {
        id
        leavePassageEntitlement
        annualLeaveEntitlement
        annualLeaveEffectDate
        sickLeaveEntitlement
        effectiveDateOfSickLeave
        positionRevision
        revisionSalaryPackage
        leavePassageEntitlementRevision
        effectiveDateOfLeavePassage
        revisionAnnualLeave
        annualEntitlementeffectiveDate
        contractEffectDate
        contractOfEmployee
        remarksWorkInfo
        createdAt
        updatedAt
        __typename
      }
      createdAt
      updatedAt
      employeeWorkInfoTerminationWorkInfoId
      employeeWorkInfoLeaveWorkInfoId
      __typename
    }
  }
`;
export const onCreateInterviewScheduleSchema = /* GraphQL */ `
  subscription OnCreateInterviewScheduleSchema(
    $filter: ModelSubscriptionInterviewScheduleSchemaFilterInput
  ) {
    onCreateInterviewScheduleSchema(filter: $filter) {
      id
      date
      time
      venue
      interviewType
      interviewer
      message
      tempID
      candidateStatus
      department
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onUpdateInterviewScheduleSchema = /* GraphQL */ `
  subscription OnUpdateInterviewScheduleSchema(
    $filter: ModelSubscriptionInterviewScheduleSchemaFilterInput
  ) {
    onUpdateInterviewScheduleSchema(filter: $filter) {
      id
      date
      time
      venue
      interviewType
      interviewer
      message
      tempID
      candidateStatus
      department
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onDeleteInterviewScheduleSchema = /* GraphQL */ `
  subscription OnDeleteInterviewScheduleSchema(
    $filter: ModelSubscriptionInterviewScheduleSchemaFilterInput
  ) {
    onDeleteInterviewScheduleSchema(filter: $filter) {
      id
      date
      time
      venue
      interviewType
      interviewer
      message
      tempID
      candidateStatus
      department
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onCreateEmployeeNonLocalAcco = /* GraphQL */ `
  subscription OnCreateEmployeeNonLocalAcco(
    $filter: ModelSubscriptionEmployeeNonLocalAccoFilterInput
  ) {
    onCreateEmployeeNonLocalAcco(filter: $filter) {
      id
      accommodation
      accommodationAddress
      empID
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onUpdateEmployeeNonLocalAcco = /* GraphQL */ `
  subscription OnUpdateEmployeeNonLocalAcco(
    $filter: ModelSubscriptionEmployeeNonLocalAccoFilterInput
  ) {
    onUpdateEmployeeNonLocalAcco(filter: $filter) {
      id
      accommodation
      accommodationAddress
      empID
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onDeleteEmployeeNonLocalAcco = /* GraphQL */ `
  subscription OnDeleteEmployeeNonLocalAcco(
    $filter: ModelSubscriptionEmployeeNonLocalAccoFilterInput
  ) {
    onDeleteEmployeeNonLocalAcco(filter: $filter) {
      id
      accommodation
      accommodationAddress
      empID
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onCreateUser = /* GraphQL */ `
  subscription OnCreateUser($filter: ModelSubscriptionUserFilterInput) {
    onCreateUser(filter: $filter) {
      id
      empID
      selectType
      setPermissions
      password
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onUpdateUser = /* GraphQL */ `
  subscription OnUpdateUser($filter: ModelSubscriptionUserFilterInput) {
    onUpdateUser(filter: $filter) {
      id
      empID
      selectType
      setPermissions
      password
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onDeleteUser = /* GraphQL */ `
  subscription OnDeleteUser($filter: ModelSubscriptionUserFilterInput) {
    onDeleteUser(filter: $filter) {
      id
      empID
      selectType
      setPermissions
      password
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onCreateLeaveStatus = /* GraphQL */ `
  subscription OnCreateLeaveStatus(
    $filter: ModelSubscriptionLeaveStatusFilterInput
  ) {
    onCreateLeaveStatus(filter: $filter) {
      id
      empID
      leaveType
      fromDate
      toDate
      days
      applyTo
      reason
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onUpdateLeaveStatus = /* GraphQL */ `
  subscription OnUpdateLeaveStatus(
    $filter: ModelSubscriptionLeaveStatusFilterInput
  ) {
    onUpdateLeaveStatus(filter: $filter) {
      id
      empID
      leaveType
      fromDate
      toDate
      days
      applyTo
      reason
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onDeleteLeaveStatus = /* GraphQL */ `
  subscription OnDeleteLeaveStatus(
    $filter: ModelSubscriptionLeaveStatusFilterInput
  ) {
    onDeleteLeaveStatus(filter: $filter) {
      id
      empID
      leaveType
      fromDate
      toDate
      days
      applyTo
      reason
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onCreateSampleTest1 = /* GraphQL */ `
  subscription OnCreateSampleTest1(
    $filter: ModelSubscriptionSampleTest1FilterInput
  ) {
    onCreateSampleTest1(filter: $filter) {
      id
      name
      email
      gender
      empID
      password
      tempID
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onUpdateSampleTest1 = /* GraphQL */ `
  subscription OnUpdateSampleTest1(
    $filter: ModelSubscriptionSampleTest1FilterInput
  ) {
    onUpdateSampleTest1(filter: $filter) {
      id
      name
      email
      gender
      empID
      password
      tempID
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onDeleteSampleTest1 = /* GraphQL */ `
  subscription OnDeleteSampleTest1(
    $filter: ModelSubscriptionSampleTest1FilterInput
  ) {
    onDeleteSampleTest1(filter: $filter) {
      id
      name
      email
      gender
      empID
      password
      tempID
      createdAt
      updatedAt
      __typename
    }
  }
`;
