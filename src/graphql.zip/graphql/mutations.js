
export const createApplicantDetails = /* GraphQL */ `
  mutation CreateApplicantDetails(
    $input: CreateApplicantDetailsInput!
    $condition: ModelApplicantDetailsConditionInput
  ) {
    createApplicantDetails(input: $input, condition: $condition) {
      id
      empID
      profilePhoto
      agent
      position
      contractType
      name
      chinese
      gender
      age
      email
      countryOfBirth
      nationality
      otherNationality
      marital
      race
      otherRace
      religion
      otherReligion
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const updateApplicantDetails = /* GraphQL */ `
  mutation UpdateApplicantDetails(
    $input: UpdateApplicantDetailsInput!
    $condition: ModelApplicantDetailsConditionInput
  ) {
    updateApplicantDetails(input: $input, condition: $condition) {
      id
      empID
      profilePhoto
      agent
      position
      contractType
      name
      chinese
      gender
      age
      email
      countryOfBirth
      nationality
      otherNationality
      marital
      race
      otherRace
      religion
      otherReligion
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const deleteApplicantDetails = /* GraphQL */ `
  mutation DeleteApplicantDetails(
    $input: DeleteApplicantDetailsInput!
    $condition: ModelApplicantDetailsConditionInput
  ) {
    deleteApplicantDetails(input: $input, condition: $condition) {
      id
      empID
      profilePhoto
      agent
      position
      contractType
      name
      chinese
      gender
      age
      email
      countryOfBirth
      nationality
      otherNationality
      marital
      race
      otherRace
      religion
      otherReligion
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const createEmployeePersonalDoc = /* GraphQL */ `
  mutation CreateEmployeePersonalDoc(
    $input: CreateEmployeePersonalDocInput!
    $condition: ModelEmployeePersonalDocConditionInput
  ) {
    createEmployeePersonalDoc(input: $input, condition: $condition) {
      id
      passportNo
      passportIssued
      passportExpiry
      passportDestination
      contactNo
      address
      employeeBadgeNumber
      sapNumber
      nationalCategory
      countryOfOrigin
      otherCountryOfOrigin
      educationLevel
      academicTechnicalQualification
      nextOfKin
      inductionBriefing
      previousEmployment
      previousEmploymentPeriod
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const updateEmployeePersonalDoc = /* GraphQL */ `
  mutation UpdateEmployeePersonalDoc(
    $input: UpdateEmployeePersonalDocInput!
    $condition: ModelEmployeePersonalDocConditionInput
  ) {
    updateEmployeePersonalDoc(input: $input, condition: $condition) {
      id
      passportNo
      passportIssued
      passportExpiry
      passportDestination
      contactNo
      address
      employeeBadgeNumber
      sapNumber
      nationalCategory
      countryOfOrigin
      otherCountryOfOrigin
      educationLevel
      academicTechnicalQualification
      nextOfKin
      inductionBriefing
      previousEmployment
      previousEmploymentPeriod
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const deleteEmployeePersonalDoc = /* GraphQL */ `
  mutation DeleteEmployeePersonalDoc(
    $input: DeleteEmployeePersonalDocInput!
    $condition: ModelEmployeePersonalDocConditionInput
  ) {
    deleteEmployeePersonalDoc(input: $input, condition: $condition) {
      id
      passportNo
      passportIssued
      passportExpiry
      passportDestination
      contactNo
      address
      employeeBadgeNumber
      sapNumber
      nationalCategory
      countryOfOrigin
      otherCountryOfOrigin
      educationLevel
      academicTechnicalQualification
      nextOfKin
      inductionBriefing
      previousEmployment
      previousEmploymentPeriod
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const createEmployeePersonalInfo = /* GraphQL */ `
  mutation CreateEmployeePersonalInfo(
    $input: CreateEmployeePersonalInfoInput!
    $condition: ModelEmployeePersonalInfoConditionInput
  ) {
    createEmployeePersonalInfo(input: $input, condition: $condition) {
      id
      empID
      name
      gender
      dateOfBirth
      email
      nationality
      otherNationality
      religion
      marital
      race
      bruneiIcNo
      bruneiIcColour
      bruneiIcExpiry
      malaysianIcNumber
      malaysianIcExpiry
      EmployeePersonalDoc {
        id
        passportNo
        passportIssued
        passportExpiry
        passportDestination
        contactNo
        address
        employeeBadgeNumber
        sapNumber
        nationalCategory
        countryOfOrigin
        otherCountryOfOrigin
        educationLevel
        academicTechnicalQualification
        nextOfKin
        inductionBriefing
        previousEmployment
        previousEmploymentPeriod
        createdAt
        updatedAt
        __typename
      }
      createdAt
      updatedAt
      employeePersonalInfoEmployeePersonalDocId
      __typename
    }
  }
`;
export const updateEmployeePersonalInfo = /* GraphQL */ `
  mutation UpdateEmployeePersonalInfo(
    $input: UpdateEmployeePersonalInfoInput!
    $condition: ModelEmployeePersonalInfoConditionInput
  ) {
    updateEmployeePersonalInfo(input: $input, condition: $condition) {
      id
      empID
      name
      gender
      dateOfBirth
      email
      nationality
      otherNationality
      religion
      marital
      race
      bruneiIcNo
      bruneiIcColour
      bruneiIcExpiry
      malaysianIcNumber
      malaysianIcExpiry
      EmployeePersonalDoc {
        id
        passportNo
        passportIssued
        passportExpiry
        passportDestination
        contactNo
        address
        employeeBadgeNumber
        sapNumber
        nationalCategory
        countryOfOrigin
        otherCountryOfOrigin
        educationLevel
        academicTechnicalQualification
        nextOfKin
        inductionBriefing
        previousEmployment
        previousEmploymentPeriod
        createdAt
        updatedAt
        __typename
      }
      createdAt
      updatedAt
      employeePersonalInfoEmployeePersonalDocId
      __typename
    }
  }
`;
export const deleteEmployeePersonalInfo = /* GraphQL */ `
  mutation DeleteEmployeePersonalInfo(
    $input: DeleteEmployeePersonalInfoInput!
    $condition: ModelEmployeePersonalInfoConditionInput
  ) {
    deleteEmployeePersonalInfo(input: $input, condition: $condition) {
      id
      empID
      name
      gender
      dateOfBirth
      email
      nationality
      otherNationality
      religion
      marital
      race
      bruneiIcNo
      bruneiIcColour
      bruneiIcExpiry
      malaysianIcNumber
      malaysianIcExpiry
      EmployeePersonalDoc {
        id
        passportNo
        passportIssued
        passportExpiry
        passportDestination
        contactNo
        address
        employeeBadgeNumber
        sapNumber
        nationalCategory
        countryOfOrigin
        otherCountryOfOrigin
        educationLevel
        academicTechnicalQualification
        nextOfKin
        inductionBriefing
        previousEmployment
        previousEmploymentPeriod
        createdAt
        updatedAt
        __typename
      }
      createdAt
      updatedAt
      employeePersonalInfoEmployeePersonalDocId
      __typename
    }
  }
`;
export const createLabourDependentPass = /* GraphQL */ `
  mutation CreateLabourDependentPass(
    $input: CreateLabourDependentPassInput!
    $condition: ModelLabourDependentPassConditionInput
  ) {
    createLabourDependentPass(input: $input, condition: $condition) {
      id
      passportLocation
      reEntryVisaApplication
      immigrationApprovalDate
      reEntryVisaExpiry
      airTicketStatus
      dependentName
      dependentPassportNumber
      dependentPassportExpiy
      relation
      labourDepositPaidBy
      labourDepositReceiptNumber
      labourDepositAmount
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const updateLabourDependentPass = /* GraphQL */ `
  mutation UpdateLabourDependentPass(
    $input: UpdateLabourDependentPassInput!
    $condition: ModelLabourDependentPassConditionInput
  ) {
    updateLabourDependentPass(input: $input, condition: $condition) {
      id
      passportLocation
      reEntryVisaApplication
      immigrationApprovalDate
      reEntryVisaExpiry
      airTicketStatus
      dependentName
      dependentPassportNumber
      dependentPassportExpiy
      relation
      labourDepositPaidBy
      labourDepositReceiptNumber
      labourDepositAmount
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const deleteLabourDependentPass = /* GraphQL */ `
  mutation DeleteLabourDependentPass(
    $input: DeleteLabourDependentPassInput!
    $condition: ModelLabourDependentPassConditionInput
  ) {
    deleteLabourDependentPass(input: $input, condition: $condition) {
      id
      passportLocation
      reEntryVisaApplication
      immigrationApprovalDate
      reEntryVisaExpiry
      airTicketStatus
      dependentName
      dependentPassportNumber
      dependentPassportExpiy
      relation
      labourDepositPaidBy
      labourDepositReceiptNumber
      labourDepositAmount
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const createLabourMedicalInfo = /* GraphQL */ `
  mutation CreateLabourMedicalInfo(
    $input: CreateLabourMedicalInfoInput!
    $condition: ModelLabourMedicalInfoConditionInput
  ) {
    createLabourMedicalInfo(input: $input, condition: $condition) {
      id
      overseasMedicalDate
      overseasMedicalExpiry
      bruhimsRegistrationDate
      bruhimsRegistrationNumber
      bruneiMedicalAppointmentDate
      bruneiMedicalExpiry
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const updateLabourMedicalInfo = /* GraphQL */ `
  mutation UpdateLabourMedicalInfo(
    $input: UpdateLabourMedicalInfoInput!
    $condition: ModelLabourMedicalInfoConditionInput
  ) {
    updateLabourMedicalInfo(input: $input, condition: $condition) {
      id
      overseasMedicalDate
      overseasMedicalExpiry
      bruhimsRegistrationDate
      bruhimsRegistrationNumber
      bruneiMedicalAppointmentDate
      bruneiMedicalExpiry
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const deleteLabourMedicalInfo = /* GraphQL */ `
  mutation DeleteLabourMedicalInfo(
    $input: DeleteLabourMedicalInfoInput!
    $condition: ModelLabourMedicalInfoConditionInput
  ) {
    deleteLabourMedicalInfo(input: $input, condition: $condition) {
      id
      overseasMedicalDate
      overseasMedicalExpiry
      bruhimsRegistrationDate
      bruhimsRegistrationNumber
      bruneiMedicalAppointmentDate
      bruneiMedicalExpiry
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const createLocalMobilization = /* GraphQL */ `
  mutation CreateLocalMobilization(
    $input: CreateLocalMobilizationInput!
    $condition: ModelLocalMobilizationConditionInput
  ) {
    createLocalMobilization(input: $input, condition: $condition) {
      id
      tempID
      mobSignDate
      mobFile
      paafApproveDate
      paafFile
      loiIssueDate
      loiAcceptDate
      loiDeclineDate
      declineReason
      loiFile
      cvecApproveDate
      cvecFile
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const updateLocalMobilization = /* GraphQL */ `
  mutation UpdateLocalMobilization(
    $input: UpdateLocalMobilizationInput!
    $condition: ModelLocalMobilizationConditionInput
  ) {
    updateLocalMobilization(input: $input, condition: $condition) {
      id
      tempID
      mobSignDate
      mobFile
      paafApproveDate
      paafFile
      loiIssueDate
      loiAcceptDate
      loiDeclineDate
      declineReason
      loiFile
      cvecApproveDate
      cvecFile
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const deleteLocalMobilization = /* GraphQL */ `
  mutation DeleteLocalMobilization(
    $input: DeleteLocalMobilizationInput!
    $condition: ModelLocalMobilizationConditionInput
  ) {
    deleteLocalMobilization(input: $input, condition: $condition) {
      id
      tempID
      mobSignDate
      mobFile
      paafApproveDate
      paafFile
      loiIssueDate
      loiAcceptDate
      loiDeclineDate
      declineReason
      loiFile
      cvecApproveDate
      cvecFile
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const createLabourWorkPass = /* GraphQL */ `
  mutation CreateLabourWorkPass(
    $input: CreateLabourWorkPassInput!
    $condition: ModelLabourWorkPassConditionInput
  ) {
    createLabourWorkPass(input: $input, condition: $condition) {
      id
      empID
      workPermitType
      arrivalStampingExpiry
      employmentPassEndorsement
      immigrationDeptDate
      employmentPassExpiry
      employmentPassStatus
      labourUploadDoc
      remarks
      LabourMedicalInfo {
        id
        overseasMedicalDate
        overseasMedicalExpiry
        bruhimsRegistrationDate
        bruhimsRegistrationNumber
        bruneiMedicalAppointmentDate
        bruneiMedicalExpiry
        createdAt
        updatedAt
        __typename
      }
      LabourDependentPass {
        id
        passportLocation
        reEntryVisaApplication
        immigrationApprovalDate
        reEntryVisaExpiry
        airTicketStatus
        dependentName
        dependentPassportNumber
        dependentPassportExpiy
        relation
        labourDepositPaidBy
        labourDepositReceiptNumber
        labourDepositAmount
        createdAt
        updatedAt
        __typename
      }
      createdAt
      updatedAt
      labourWorkPassLabourMedicalInfoId
      labourWorkPassLabourDependentPassId
      __typename
    }
  }
`;
export const updateLabourWorkPass = /* GraphQL */ `
  mutation UpdateLabourWorkPass(
    $input: UpdateLabourWorkPassInput!
    $condition: ModelLabourWorkPassConditionInput
  ) {
    updateLabourWorkPass(input: $input, condition: $condition) {
      id
      empID
      workPermitType
      arrivalStampingExpiry
      employmentPassEndorsement
      immigrationDeptDate
      employmentPassExpiry
      employmentPassStatus
      labourUploadDoc
      remarks
      LabourMedicalInfo {
        id
        overseasMedicalDate
        overseasMedicalExpiry
        bruhimsRegistrationDate
        bruhimsRegistrationNumber
        bruneiMedicalAppointmentDate
        bruneiMedicalExpiry
        createdAt
        updatedAt
        __typename
      }
      LabourDependentPass {
        id
        passportLocation
        reEntryVisaApplication
        immigrationApprovalDate
        reEntryVisaExpiry
        airTicketStatus
        dependentName
        dependentPassportNumber
        dependentPassportExpiy
        relation
        labourDepositPaidBy
        labourDepositReceiptNumber
        labourDepositAmount
        createdAt
        updatedAt
        __typename
      }
      createdAt
      updatedAt
      labourWorkPassLabourMedicalInfoId
      labourWorkPassLabourDependentPassId
      __typename
    }
  }
`;
export const deleteLabourWorkPass = /* GraphQL */ `
  mutation DeleteLabourWorkPass(
    $input: DeleteLabourWorkPassInput!
    $condition: ModelLabourWorkPassConditionInput
  ) {
    deleteLabourWorkPass(input: $input, condition: $condition) {
      id
      empID
      workPermitType
      arrivalStampingExpiry
      employmentPassEndorsement
      immigrationDeptDate
      employmentPassExpiry
      employmentPassStatus
      labourUploadDoc
      remarks
      LabourMedicalInfo {
        id
        overseasMedicalDate
        overseasMedicalExpiry
        bruhimsRegistrationDate
        bruhimsRegistrationNumber
        bruneiMedicalAppointmentDate
        bruneiMedicalExpiry
        createdAt
        updatedAt
        __typename
      }
      LabourDependentPass {
        id
        passportLocation
        reEntryVisaApplication
        immigrationApprovalDate
        reEntryVisaExpiry
        airTicketStatus
        dependentName
        dependentPassportNumber
        dependentPassportExpiy
        relation
        labourDepositPaidBy
        labourDepositReceiptNumber
        labourDepositAmount
        createdAt
        updatedAt
        __typename
      }
      createdAt
      updatedAt
      labourWorkPassLabourMedicalInfoId
      labourWorkPassLabourDependentPassId
      __typename
    }
  }
`;
export const createLeaveWorkInfo = /* GraphQL */ `
  mutation CreateLeaveWorkInfo(
    $input: CreateLeaveWorkInfoInput!
    $condition: ModelLeaveWorkInfoConditionInput
  ) {
    createLeaveWorkInfo(input: $input, condition: $condition) {
      id
      leavePassageEntitlement
      annualLeaveEntitlement
      annualLeaveEffectDate
      sickLeaveEntitlement
      effectiveDateOfSickLeave
      positionRevision
      revisionSalaryPackage
      leavePassageEntitlementRevision
      effectiveDateOfLeavePassage
      revisionAnnualLeave
      annualEntitlementeffectiveDate
      contractEffectDate
      contractOfEmployee
      remarksWorkInfo
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const updateLeaveWorkInfo = /* GraphQL */ `
  mutation UpdateLeaveWorkInfo(
    $input: UpdateLeaveWorkInfoInput!
    $condition: ModelLeaveWorkInfoConditionInput
  ) {
    updateLeaveWorkInfo(input: $input, condition: $condition) {
      id
      leavePassageEntitlement
      annualLeaveEntitlement
      annualLeaveEffectDate
      sickLeaveEntitlement
      effectiveDateOfSickLeave
      positionRevision
      revisionSalaryPackage
      leavePassageEntitlementRevision
      effectiveDateOfLeavePassage
      revisionAnnualLeave
      annualEntitlementeffectiveDate
      contractEffectDate
      contractOfEmployee
      remarksWorkInfo
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const deleteLeaveWorkInfo = /* GraphQL */ `
  mutation DeleteLeaveWorkInfo(
    $input: DeleteLeaveWorkInfoInput!
    $condition: ModelLeaveWorkInfoConditionInput
  ) {
    deleteLeaveWorkInfo(input: $input, condition: $condition) {
      id
      leavePassageEntitlement
      annualLeaveEntitlement
      annualLeaveEffectDate
      sickLeaveEntitlement
      effectiveDateOfSickLeave
      positionRevision
      revisionSalaryPackage
      leavePassageEntitlementRevision
      effectiveDateOfLeavePassage
      revisionAnnualLeave
      annualEntitlementeffectiveDate
      contractEffectDate
      contractOfEmployee
      remarksWorkInfo
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const createTerminationWorkInfo = /* GraphQL */ `
  mutation CreateTerminationWorkInfo(
    $input: CreateTerminationWorkInfoInput!
    $condition: ModelTerminationWorkInfoConditionInput
  ) {
    createTerminationWorkInfo(input: $input, condition: $condition) {
      id
      resignationDate
      terminationDate
      terminationNoticeProbation
      terminationNoticeConfirmation
      resignationNoticeProbation
      resignationNoticeConfirmation
      reasonOfResignation
      reasonOfTermination
      destinationOfEntitlement
      durationPeriodEntitlement
      dateOfEntitlement
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const updateTerminationWorkInfo = /* GraphQL */ `
  mutation UpdateTerminationWorkInfo(
    $input: UpdateTerminationWorkInfoInput!
    $condition: ModelTerminationWorkInfoConditionInput
  ) {
    updateTerminationWorkInfo(input: $input, condition: $condition) {
      id
      resignationDate
      terminationDate
      terminationNoticeProbation
      terminationNoticeConfirmation
      resignationNoticeProbation
      resignationNoticeConfirmation
      reasonOfResignation
      reasonOfTermination
      destinationOfEntitlement
      durationPeriodEntitlement
      dateOfEntitlement
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const deleteTerminationWorkInfo = /* GraphQL */ `
  mutation DeleteTerminationWorkInfo(
    $input: DeleteTerminationWorkInfoInput!
    $condition: ModelTerminationWorkInfoConditionInput
  ) {
    deleteTerminationWorkInfo(input: $input, condition: $condition) {
      id
      resignationDate
      terminationDate
      terminationNoticeProbation
      terminationNoticeConfirmation
      resignationNoticeProbation
      resignationNoticeConfirmation
      reasonOfResignation
      reasonOfTermination
      destinationOfEntitlement
      durationPeriodEntitlement
      dateOfEntitlement
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const createEmployeeWorkInfo = /* GraphQL */ `
  mutation CreateEmployeeWorkInfo(
    $input: CreateEmployeeWorkInfoInput!
    $condition: ModelEmployeeWorkInfoConditionInput
  ) {
    createEmployeeWorkInfo(input: $input, condition: $condition) {
      id
      empID
      dateOfJoin
      department
      workPosition
      upgradePosition
      jobDescription
      skillPool
      workStatus
      contractStartDate
      contractEndDate
      contractPeriodStatus
      ProbationaryStartDate
      ProbationaryEndDate
      normalWorkingHours
      normalWorkingWeek
      salaryType
      normalWorkingMonth
      employmentWorkStatus
      jobCategory
      otherJobCategory
      upgradeDate
      TerminationWorkInfo {
        id
        resignationDate
        terminationDate
        terminationNoticeProbation
        terminationNoticeConfirmation
        resignationNoticeProbation
        resignationNoticeConfirmation
        reasonOfResignation
        reasonOfTermination
        destinationOfEntitlement
        durationPeriodEntitlement
        dateOfEntitlement
        createdAt
        updatedAt
        __typename
      }
      LeaveWorkInfo {
        id
        leavePassageEntitlement
        annualLeaveEntitlement
        annualLeaveEffectDate
        sickLeaveEntitlement
        effectiveDateOfSickLeave
        positionRevision
        revisionSalaryPackage
        leavePassageEntitlementRevision
        effectiveDateOfLeavePassage
        revisionAnnualLeave
        annualEntitlementeffectiveDate
        contractEffectDate
        contractOfEmployee
        remarksWorkInfo
        createdAt
        updatedAt
        __typename
      }
      createdAt
      updatedAt
      employeeWorkInfoTerminationWorkInfoId
      employeeWorkInfoLeaveWorkInfoId
      __typename
    }
  }
`;
export const updateEmployeeWorkInfo = /* GraphQL */ `
  mutation UpdateEmployeeWorkInfo(
    $input: UpdateEmployeeWorkInfoInput!
    $condition: ModelEmployeeWorkInfoConditionInput
  ) {
    updateEmployeeWorkInfo(input: $input, condition: $condition) {
      id
      empID
      dateOfJoin
      department
      workPosition
      upgradePosition
      jobDescription
      skillPool
      workStatus
      contractStartDate
      contractEndDate
      contractPeriodStatus
      ProbationaryStartDate
      ProbationaryEndDate
      normalWorkingHours
      normalWorkingWeek
      salaryType
      normalWorkingMonth
      employmentWorkStatus
      jobCategory
      otherJobCategory
      upgradeDate
      TerminationWorkInfo {
        id
        resignationDate
        terminationDate
        terminationNoticeProbation
        terminationNoticeConfirmation
        resignationNoticeProbation
        resignationNoticeConfirmation
        reasonOfResignation
        reasonOfTermination
        destinationOfEntitlement
        durationPeriodEntitlement
        dateOfEntitlement
        createdAt
        updatedAt
        __typename
      }
      LeaveWorkInfo {
        id
        leavePassageEntitlement
        annualLeaveEntitlement
        annualLeaveEffectDate
        sickLeaveEntitlement
        effectiveDateOfSickLeave
        positionRevision
        revisionSalaryPackage
        leavePassageEntitlementRevision
        effectiveDateOfLeavePassage
        revisionAnnualLeave
        annualEntitlementeffectiveDate
        contractEffectDate
        contractOfEmployee
        remarksWorkInfo
        createdAt
        updatedAt
        __typename
      }
      createdAt
      updatedAt
      employeeWorkInfoTerminationWorkInfoId
      employeeWorkInfoLeaveWorkInfoId
      __typename
    }
  }
`;
export const deleteEmployeeWorkInfo = /* GraphQL */ `
  mutation DeleteEmployeeWorkInfo(
    $input: DeleteEmployeeWorkInfoInput!
    $condition: ModelEmployeeWorkInfoConditionInput
  ) {
    deleteEmployeeWorkInfo(input: $input, condition: $condition) {
      id
      empID
      dateOfJoin
      department
      workPosition
      upgradePosition
      jobDescription
      skillPool
      workStatus
      contractStartDate
      contractEndDate
      contractPeriodStatus
      ProbationaryStartDate
      ProbationaryEndDate
      normalWorkingHours
      normalWorkingWeek
      salaryType
      normalWorkingMonth
      employmentWorkStatus
      jobCategory
      otherJobCategory
      upgradeDate
      TerminationWorkInfo {
        id
        resignationDate
        terminationDate
        terminationNoticeProbation
        terminationNoticeConfirmation
        resignationNoticeProbation
        resignationNoticeConfirmation
        reasonOfResignation
        reasonOfTermination
        destinationOfEntitlement
        durationPeriodEntitlement
        dateOfEntitlement
        createdAt
        updatedAt
        __typename
      }
      LeaveWorkInfo {
        id
        leavePassageEntitlement
        annualLeaveEntitlement
        annualLeaveEffectDate
        sickLeaveEntitlement
        effectiveDateOfSickLeave
        positionRevision
        revisionSalaryPackage
        leavePassageEntitlementRevision
        effectiveDateOfLeavePassage
        revisionAnnualLeave
        annualEntitlementeffectiveDate
        contractEffectDate
        contractOfEmployee
        remarksWorkInfo
        createdAt
        updatedAt
        __typename
      }
      createdAt
      updatedAt
      employeeWorkInfoTerminationWorkInfoId
      employeeWorkInfoLeaveWorkInfoId
      __typename
    }
  }
`;
export const createInterviewScheduleSchema = /* GraphQL */ `
  mutation CreateInterviewScheduleSchema(
    $input: CreateInterviewScheduleSchemaInput!
    $condition: ModelInterviewScheduleSchemaConditionInput
  ) {
    createInterviewScheduleSchema(input: $input, condition: $condition) {
      id
      date
      time
      venue
      interviewType
      interviewer
      message
      tempID
      candidateStatus
      department
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const updateInterviewScheduleSchema = /* GraphQL */ `
  mutation UpdateInterviewScheduleSchema(
    $input: UpdateInterviewScheduleSchemaInput!
    $condition: ModelInterviewScheduleSchemaConditionInput
  ) {
    updateInterviewScheduleSchema(input: $input, condition: $condition) {
      id
      date
      time
      venue
      interviewType
      interviewer
      message
      tempID
      candidateStatus
      department
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const deleteInterviewScheduleSchema = /* GraphQL */ `
  mutation DeleteInterviewScheduleSchema(
    $input: DeleteInterviewScheduleSchemaInput!
    $condition: ModelInterviewScheduleSchemaConditionInput
  ) {
    deleteInterviewScheduleSchema(input: $input, condition: $condition) {
      id
      date
      time
      venue
      interviewType
      interviewer
      message
      tempID
      candidateStatus
      department
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const createEmployeeNonLocalAcco = /* GraphQL */ `
  mutation CreateEmployeeNonLocalAcco(
    $input: CreateEmployeeNonLocalAccoInput!
    $condition: ModelEmployeeNonLocalAccoConditionInput
  ) {
    createEmployeeNonLocalAcco(input: $input, condition: $condition) {
      id
      accommodation
      accommodationAddress
      empID
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const updateEmployeeNonLocalAcco = /* GraphQL */ `
  mutation UpdateEmployeeNonLocalAcco(
    $input: UpdateEmployeeNonLocalAccoInput!
    $condition: ModelEmployeeNonLocalAccoConditionInput
  ) {
    updateEmployeeNonLocalAcco(input: $input, condition: $condition) {
      id
      accommodation
      accommodationAddress
      empID
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const deleteEmployeeNonLocalAcco = /* GraphQL */ `
  mutation DeleteEmployeeNonLocalAcco(
    $input: DeleteEmployeeNonLocalAccoInput!
    $condition: ModelEmployeeNonLocalAccoConditionInput
  ) {
    deleteEmployeeNonLocalAcco(input: $input, condition: $condition) {
      id
      accommodation
      accommodationAddress
      empID
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const createUser = /* GraphQL */ `
  mutation CreateUser(
    $input: CreateUserInput!
    $condition: ModelUserConditionInput
  ) {
    createUser(input: $input, condition: $condition) {
      id
      empID
      selectType
      setPermissions
      password
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const updateUser = /* GraphQL */ `
  mutation UpdateUser(
    $input: UpdateUserInput!
    $condition: ModelUserConditionInput
  ) {
    updateUser(input: $input, condition: $condition) {
      id
      empID
      selectType
      setPermissions
      password
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const deleteUser = /* GraphQL */ `
  mutation DeleteUser(
    $input: DeleteUserInput!
    $condition: ModelUserConditionInput
  ) {
    deleteUser(input: $input, condition: $condition) {
      id
      empID
      selectType
      setPermissions
      password
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const createLeaveStatus = /* GraphQL */ `
  mutation CreateLeaveStatus(
    $input: CreateLeaveStatusInput!
    $condition: ModelLeaveStatusConditionInput
  ) {
    createLeaveStatus(input: $input, condition: $condition) {
      id
      empID
      leaveType
      fromDate
      toDate
      days
      applyTo
      reason
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const updateLeaveStatus = /* GraphQL */ `
  mutation UpdateLeaveStatus(
    $input: UpdateLeaveStatusInput!
    $condition: ModelLeaveStatusConditionInput
  ) {
    updateLeaveStatus(input: $input, condition: $condition) {
      id
      empID
      leaveType
      fromDate
      toDate
      days
      applyTo
      reason
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const deleteLeaveStatus = /* GraphQL */ `
  mutation DeleteLeaveStatus(
    $input: DeleteLeaveStatusInput!
    $condition: ModelLeaveStatusConditionInput
  ) {
    deleteLeaveStatus(input: $input, condition: $condition) {
      id
      empID
      leaveType
      fromDate
      toDate
      days
      applyTo
      reason
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const createSampleTest1 = /* GraphQL */ `
  mutation CreateSampleTest1(
    $input: CreateSampleTest1Input!
    $condition: ModelSampleTest1ConditionInput
  ) {
    createSampleTest1(input: $input, condition: $condition) {
      id
      name
      email
      gender
      empID
      password
      tempID
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const updateSampleTest1 = /* GraphQL */ `
  mutation UpdateSampleTest1(
    $input: UpdateSampleTest1Input!
    $condition: ModelSampleTest1ConditionInput
  ) {
    updateSampleTest1(input: $input, condition: $condition) {
      id
      name
      email
      gender
      empID
      password
      tempID
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const deleteSampleTest1 = /* GraphQL */ `
  mutation DeleteSampleTest1(
    $input: DeleteSampleTest1Input!
    $condition: ModelSampleTest1ConditionInput
  ) {
    deleteSampleTest1(input: $input, condition: $condition) {
      id
      name
      email
      gender
      empID
      password
      tempID
      createdAt
      updatedAt
      __typename
    }
  }
`;
