/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const getApplicantDetails = /* GraphQL */ `
  query GetApplicantDetails($id: ID!) {
    getApplicantDetails(id: $id) {
      id
      empID
      profilePhoto
      agent
      position
      contractType
      name
      chinese
      gender
      age
      email
      countryOfBirth
      nationality
      otherNationality
      marital
      race
      otherRace
      religion
      otherReligion
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const listApplicantDetails = /* GraphQL */ `
  query ListApplicantDetails(
    $filter: ModelApplicantDetailsFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listApplicantDetails(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
    ) {
      items {
        id
        empID
        profilePhoto
        agent
        position
        contractType
        name
        chinese
        gender
        age
        email
        countryOfBirth
        nationality
        otherNationality
        marital
        race
        otherRace
        religion
        otherReligion
        createdAt
        updatedAt
        __typename
      }
      nextToken
      __typename
    }
  }
`;
export const getEmployeePersonalDoc = /* GraphQL */ `
  query GetEmployeePersonalDoc($id: ID!) {
    getEmployeePersonalDoc(id: $id) {
      id
      passportNo
      passportIssued
      passportExpiry
      passportDestination
      contactNo
      address
      employeeBadgeNumber
      sapNumber
      nationalCategory
      countryOfOrigin
      otherCountryOfOrigin
      educationLevel
      academicTechnicalQualification
      nextOfKin
      inductionBriefing
      previousEmployment
      previousEmploymentPeriod
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const listEmployeePersonalDocs = /* GraphQL */ `
  query ListEmployeePersonalDocs(
    $filter: ModelEmployeePersonalDocFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listEmployeePersonalDocs(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
    ) {
      items {
        id
        passportNo
        passportIssued
        passportExpiry
        passportDestination
        contactNo
        address
        employeeBadgeNumber
        sapNumber
        nationalCategory
        countryOfOrigin
        otherCountryOfOrigin
        educationLevel
        academicTechnicalQualification
        nextOfKin
        inductionBriefing
        previousEmployment
        previousEmploymentPeriod
        createdAt
        updatedAt
        __typename
      }
      nextToken
      __typename
    }
  }
`;
export const getEmployeePersonalInfo = /* GraphQL */ `
  query GetEmployeePersonalInfo($id: ID!) {
    getEmployeePersonalInfo(id: $id) {
      id
      empID
      name
      gender
      dateOfBirth
      email
      nationality
      otherNationality
      religion
      marital
      race
      bruneiIcNo
      bruneiIcColour
      bruneiIcExpiry
      malaysianIcNumber
      malaysianIcExpiry
      EmployeePersonalDoc {
        id
        passportNo
        passportIssued
        passportExpiry
        passportDestination
        contactNo
        address
        employeeBadgeNumber
        sapNumber
        nationalCategory
        countryOfOrigin
        otherCountryOfOrigin
        educationLevel
        academicTechnicalQualification
        nextOfKin
        inductionBriefing
        previousEmployment
        previousEmploymentPeriod
        createdAt
        updatedAt
        __typename
      }
      createdAt
      updatedAt
      employeePersonalInfoEmployeePersonalDocId
      __typename
    }
  }
`;
export const listEmployeePersonalInfos = /* GraphQL */ `
  query ListEmployeePersonalInfos(
    $filter: ModelEmployeePersonalInfoFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listEmployeePersonalInfos(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
    ) {
      items {
        id
        empID
        name
        gender
        dateOfBirth
        email
        nationality
        otherNationality
        religion
        marital
        race
        bruneiIcNo
        bruneiIcColour
        bruneiIcExpiry
        malaysianIcNumber
        malaysianIcExpiry
        createdAt
        updatedAt
        employeePersonalInfoEmployeePersonalDocId
        __typename
      }
      nextToken
      __typename
    }
  }
`;
export const getLabourDependentPass = /* GraphQL */ `
  query GetLabourDependentPass($id: ID!) {
    getLabourDependentPass(id: $id) {
      id
      passportLocation
      reEntryVisaApplication
      immigrationApprovalDate
      reEntryVisaExpiry
      airTicketStatus
      dependentName
      dependentPassportNumber
      dependentPassportExpiy
      relation
      labourDepositPaidBy
      labourDepositReceiptNumber
      labourDepositAmount
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const listLabourDependentPasses = /* GraphQL */ `
  query ListLabourDependentPasses(
    $filter: ModelLabourDependentPassFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listLabourDependentPasses(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
    ) {
      items {
        id
        passportLocation
        reEntryVisaApplication
        immigrationApprovalDate
        reEntryVisaExpiry
        airTicketStatus
        dependentName
        dependentPassportNumber
        dependentPassportExpiy
        relation
        labourDepositPaidBy
        labourDepositReceiptNumber
        labourDepositAmount
        createdAt
        updatedAt
        __typename
      }
      nextToken
      __typename
    }
  }
`;
export const getLabourMedicalInfo = /* GraphQL */ `
  query GetLabourMedicalInfo($id: ID!) {
    getLabourMedicalInfo(id: $id) {
      id
      overseasMedicalDate
      overseasMedicalExpiry
      bruhimsRegistrationDate
      bruhimsRegistrationNumber
      bruneiMedicalAppointmentDate
      bruneiMedicalExpiry
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const listLabourMedicalInfos = /* GraphQL */ `
  query ListLabourMedicalInfos(
    $filter: ModelLabourMedicalInfoFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listLabourMedicalInfos(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
    ) {
      items {
        id
        overseasMedicalDate
        overseasMedicalExpiry
        bruhimsRegistrationDate
        bruhimsRegistrationNumber
        bruneiMedicalAppointmentDate
        bruneiMedicalExpiry
        createdAt
        updatedAt
        __typename
      }
      nextToken
      __typename
    }
  }
`;
export const getLocalMobilization = /* GraphQL */ `
  query GetLocalMobilization($id: ID!) {
    getLocalMobilization(id: $id) {
      id
      tempID
      mobSignDate
      mobFile
      paafApproveDate
      paafFile
      loiIssueDate
      loiAcceptDate
      loiDeclineDate
      declineReason
      loiFile
      cvecApproveDate
      cvecFile
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const listLocalMobilizations = /* GraphQL */ `
  query ListLocalMobilizations(
    $filter: ModelLocalMobilizationFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listLocalMobilizations(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
    ) {
      items {
        id
        tempID
        mobSignDate
        mobFile
        paafApproveDate
        paafFile
        loiIssueDate
        loiAcceptDate
        loiDeclineDate
        declineReason
        loiFile
        cvecApproveDate
        cvecFile
        createdAt
        updatedAt
        __typename
      }
      nextToken
      __typename
    }
  }
`;
export const getLabourWorkPass = /* GraphQL */ `
  query GetLabourWorkPass($id: ID!) {
    getLabourWorkPass(id: $id) {
      id
      empID
      workPermitType
      arrivalStampingExpiry
      employmentPassEndorsement
      immigrationDeptDate
      employmentPassExpiry
      employmentPassStatus
      labourUploadDoc
      remarks
      LabourMedicalInfo {
        id
        overseasMedicalDate
        overseasMedicalExpiry
        bruhimsRegistrationDate
        bruhimsRegistrationNumber
        bruneiMedicalAppointmentDate
        bruneiMedicalExpiry
        createdAt
        updatedAt
        __typename
      }
      LabourDependentPass {
        id
        passportLocation
        reEntryVisaApplication
        immigrationApprovalDate
        reEntryVisaExpiry
        airTicketStatus
        dependentName
        dependentPassportNumber
        dependentPassportExpiy
        relation
        labourDepositPaidBy
        labourDepositReceiptNumber
        labourDepositAmount
        createdAt
        updatedAt
        __typename
      }
      createdAt
      updatedAt
      labourWorkPassLabourMedicalInfoId
      labourWorkPassLabourDependentPassId
      __typename
    }
  }
`;
export const listLabourWorkPasses = /* GraphQL */ `
  query ListLabourWorkPasses(
    $filter: ModelLabourWorkPassFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listLabourWorkPasses(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
    ) {
      items {
        id
        empID
        workPermitType
        arrivalStampingExpiry
        employmentPassEndorsement
        immigrationDeptDate
        employmentPassExpiry
        employmentPassStatus
        labourUploadDoc
        remarks
        createdAt
        updatedAt
        labourWorkPassLabourMedicalInfoId
        labourWorkPassLabourDependentPassId
        __typename
      }
      nextToken
      __typename
    }
  }
`;
export const getLeaveWorkInfo = /* GraphQL */ `
  query GetLeaveWorkInfo($id: ID!) {
    getLeaveWorkInfo(id: $id) {
      id
      leavePassageEntitlement
      annualLeaveEntitlement
      annualLeaveEffectDate
      sickLeaveEntitlement
      effectiveDateOfSickLeave
      positionRevision
      revisionSalaryPackage
      leavePassageEntitlementRevision
      effectiveDateOfLeavePassage
      revisionAnnualLeave
      annualEntitlementeffectiveDate
      contractEffectDate
      contractOfEmployee
      remarksWorkInfo
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const listLeaveWorkInfos = /* GraphQL */ `
  query ListLeaveWorkInfos(
    $filter: ModelLeaveWorkInfoFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listLeaveWorkInfos(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        leavePassageEntitlement
        annualLeaveEntitlement
        annualLeaveEffectDate
        sickLeaveEntitlement
        effectiveDateOfSickLeave
        positionRevision
        revisionSalaryPackage
        leavePassageEntitlementRevision
        effectiveDateOfLeavePassage
        revisionAnnualLeave
        annualEntitlementeffectiveDate
        contractEffectDate
        contractOfEmployee
        remarksWorkInfo
        createdAt
        updatedAt
        __typename
      }
      nextToken
      __typename
    }
  }
`;
export const getTerminationWorkInfo = /* GraphQL */ `
  query GetTerminationWorkInfo($id: ID!) {
    getTerminationWorkInfo(id: $id) {
      id
      resignationDate
      terminationDate
      terminationNoticeProbation
      terminationNoticeConfirmation
      resignationNoticeProbation
      resignationNoticeConfirmation
      reasonOfResignation
      reasonOfTermination
      destinationOfEntitlement
      durationPeriodEntitlement
      dateOfEntitlement
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const listTerminationWorkInfos = /* GraphQL */ `
  query ListTerminationWorkInfos(
    $filter: ModelTerminationWorkInfoFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listTerminationWorkInfos(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
    ) {
      items {
        id
        resignationDate
        terminationDate
        terminationNoticeProbation
        terminationNoticeConfirmation
        resignationNoticeProbation
        resignationNoticeConfirmation
        reasonOfResignation
        reasonOfTermination
        destinationOfEntitlement
        durationPeriodEntitlement
        dateOfEntitlement
        createdAt
        updatedAt
        __typename
      }
      nextToken
      __typename
    }
  }
`;
export const getEmployeeWorkInfo = /* GraphQL */ `
  query GetEmployeeWorkInfo($id: ID!) {
    getEmployeeWorkInfo(id: $id) {
      id
      empID
      dateOfJoin
      department
      workPosition
      upgradePosition
      jobDescription
      skillPool
      workStatus
      contractStartDate
      contractEndDate
      contractPeriodStatus
      ProbationaryStartDate
      ProbationaryEndDate
      normalWorkingHours
      normalWorkingWeek
      salaryType
      normalWorkingMonth
      employmentWorkStatus
      jobCategory
      otherJobCategory
      upgradeDate
      TerminationWorkInfo {
        id
        resignationDate
        terminationDate
        terminationNoticeProbation
        terminationNoticeConfirmation
        resignationNoticeProbation
        resignationNoticeConfirmation
        reasonOfResignation
        reasonOfTermination
        destinationOfEntitlement
        durationPeriodEntitlement
        dateOfEntitlement
        createdAt
        updatedAt
        __typename
      }
      LeaveWorkInfo {
        id
        leavePassageEntitlement
        annualLeaveEntitlement
        annualLeaveEffectDate
        sickLeaveEntitlement
        effectiveDateOfSickLeave
        positionRevision
        revisionSalaryPackage
        leavePassageEntitlementRevision
        effectiveDateOfLeavePassage
        revisionAnnualLeave
        annualEntitlementeffectiveDate
        contractEffectDate
        contractOfEmployee
        remarksWorkInfo
        createdAt
        updatedAt
        __typename
      }
      createdAt
      updatedAt
      employeeWorkInfoTerminationWorkInfoId
      employeeWorkInfoLeaveWorkInfoId
      __typename
    }
  }
`;
export const listEmployeeWorkInfos = /* GraphQL */ `
  query ListEmployeeWorkInfos(
    $filter: ModelEmployeeWorkInfoFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listEmployeeWorkInfos(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
    ) {
      items {
        id
        empID
        dateOfJoin
        department
        workPosition
        upgradePosition
        jobDescription
        skillPool
        workStatus
        contractStartDate
        contractEndDate
        contractPeriodStatus
        ProbationaryStartDate
        ProbationaryEndDate
        normalWorkingHours
        normalWorkingWeek
        salaryType
        normalWorkingMonth
        employmentWorkStatus
        jobCategory
        otherJobCategory
        upgradeDate
        createdAt
        updatedAt
        employeeWorkInfoTerminationWorkInfoId
        employeeWorkInfoLeaveWorkInfoId
        __typename
      }
      nextToken
      __typename
    }
  }
`;
export const getInterviewScheduleSchema = /* GraphQL */ `
  query GetInterviewScheduleSchema($id: ID!) {
    getInterviewScheduleSchema(id: $id) {
      id
      date
      time
      venue
      interviewType
      interviewer
      message
      tempID
      candidateStatus
      department
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const listInterviewScheduleSchemas = /* GraphQL */ `
  query ListInterviewScheduleSchemas(
    $filter: ModelInterviewScheduleSchemaFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listInterviewScheduleSchemas(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
    ) {
      items {
        id
        date
        time
        venue
        interviewType
        interviewer
        message
        tempID
        candidateStatus
        department
        createdAt
        updatedAt
        __typename
      }
      nextToken
      __typename
    }
  }
`;
export const getEmployeeNonLocalAcco = /* GraphQL */ `
  query GetEmployeeNonLocalAcco($id: ID!) {
    getEmployeeNonLocalAcco(id: $id) {
      id
      accommodation
      accommodationAddress
      empID
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const listEmployeeNonLocalAccos = /* GraphQL */ `
  query ListEmployeeNonLocalAccos(
    $filter: ModelEmployeeNonLocalAccoFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listEmployeeNonLocalAccos(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
    ) {
      items {
        id
        accommodation
        accommodationAddress
        empID
        createdAt
        updatedAt
        __typename
      }
      nextToken
      __typename
    }
  }
`;
export const getUser = /* GraphQL */ `
  query GetUser($id: ID!) {
    getUser(id: $id) {
      id
      empID
      selectType
      setPermissions
      password
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const listUsers = /* GraphQL */ `
  query ListUsers(
    $filter: ModelUserFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listUsers(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        empID
        selectType
        setPermissions
        password
        createdAt
        updatedAt
        __typename
      }
      nextToken
      __typename
    }
  }
`;
export const getLeaveStatus = /* GraphQL */ `
  query GetLeaveStatus($id: ID!) {
    getLeaveStatus(id: $id) {
      id
      empID
      leaveType
      fromDate
      toDate
      days
      applyTo
      reason
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const listLeaveStatuses = /* GraphQL */ `
  query ListLeaveStatuses(
    $filter: ModelLeaveStatusFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listLeaveStatuses(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        empID
        leaveType
        fromDate
        toDate
        days
        applyTo
        reason
        createdAt
        updatedAt
        __typename
      }
      nextToken
      __typename
    }
  }
`;
export const getSampleTest1 = /* GraphQL */ `
  query GetSampleTest1($id: ID!) {
    getSampleTest1(id: $id) {
      id
      name
      email
      gender
      empID
      password
      tempID
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const listSampleTest1s = /* GraphQL */ `
  query ListSampleTest1s(
    $filter: ModelSampleTest1FilterInput
    $limit: Int
    $nextToken: String
  ) {
    listSampleTest1s(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        name
        email
        gender
        empID
        password
        tempID
        createdAt
        updatedAt
        __typename
      }
      nextToken
      __typename
    }
  }
`;
