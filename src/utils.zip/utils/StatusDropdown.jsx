
export const statusOptions = [
    "CVEC",
    "PAAF",
    "MOBILIZATION",
    "SAWP",
    "VALUES",
    "LOI",
    "SAWP",
    "DOE"
  ];