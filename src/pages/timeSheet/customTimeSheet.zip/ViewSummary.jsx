// import { useState } from "react";
// import { SearchBoxForTimeSheet } from "../../utils/SearchBoxForTimeSheet";
// import { FaAngleDown } from "react-icons/fa";
// import { Link } from "react-router-dom";
// import { FilterForTimeSheet } from "./FilterForTimeSheet";
// export const ViewSummary = () => {
//   const [categoryFilter, setCategoryFilter] = useState("BLNG");
//   const [toggleClick, setToggleClick] = useState(false);

import { generateClient } from "@aws-amplify/api";
import { useEffect, useState } from "react";
import {
  getLeaveStatus,
  listEmpPersonalInfos,
  listEmpWorkInfos,
  listLeaveStatuses,
  listOffshoreSheets,
} from "../../graphql/queries";
import { useFetchData } from "./customTimeSheet/UseFetchData";

//   const [startDate, setStartDate] = useState("");
//   const [endDate, setEndDate] = useState("");
//   const [loading, setLoading] = useState(true);

//   const data = [
//     {
//       name: "ABDUL AZIM BIN A.S. NARODIN",
//       project: "50***F10",
//       hours: "12",
//       total: { NH: 84, ND: 7, PH: 0, OT: 3 },
//       verified: "YES",
//       updater: "ROZATUL AZRNIE BINTI SANIF",
//     },
//     {
//       name: "AHMAD SHAHIZAN BIN HAINI",
//       project: "50***F10",
//       hours: "12",
//       total: { NH: 84, ND: 7, PH: 0, OT: 3 },
//       verified: "YES",
//       updater: "ROZATUL AZRNIE BINTI SANIF",
//     },
//     // Add more entries here
//   ];

//   return (
//     // <div className="overflow-x-auto">
//     //   <table className="table-auto border-collapse border border-gray-300 w-full text-sm text-left">
//     //     <thead>
//     //       <tr className="bg-gray-200">
//     //         <th className="border border-gray-300 px-2 py-1">Employee Name</th>
//     //         <th className="border border-gray-300 px-2 py-1">Project</th>
//     //         <th className="border border-gray-300 px-2 py-1">Hours/Day</th>
//     //         <th className="border border-gray-300 px-2 py-1">NH</th>
//     //         <th className="border border-gray-300 px-2 py-1">ND</th>
//     //         <th className="border border-gray-300 px-2 py-1">PH</th>
//     //         <th className="border border-gray-300 px-2 py-1">OT</th>
//     //         <th className="border border-gray-300 px-2 py-1">Verified</th>
//     //         <th className="border border-gray-300 px-2 py-1">Updater</th>
//     //       </tr>
//     //     </thead>
//     //     <tbody>
//     //       {data.map((row, index) => (
//     //         <tr
//     //           key={index}
//     //           className={index % 2 === 0 ? "bg-white" : "bg-gray-100"}
//     //         >
//     //           <td className="border border-gray-300 px-2 py-1">{row.name}</td>
//     //           <td className="border border-gray-300 px-2 py-1">
//     //             {row.project}
//     //           </td>
//     //           <td className="border border-gray-300 px-2 py-1">{row.hours}</td>
//     //           <td className="border border-gray-300 px-2 py-1">
//     //             {row.total.NH}
//     //           </td>
//     //           <td className="border border-gray-300 px-2 py-1">
//     //             {row.total.ND}
//     //           </td>
//     //           <td className="border border-gray-300 px-2 py-1">
//     //             {row.total.PH}
//     //           </td>
//     //           <td className="border border-gray-300 px-2 py-1">
//     //             {row.total.OT}
//     //           </td>
//     //           <td className="border border-gray-300 px-2 py-1">
//     //             {row.verified}
//     //           </td>
//     //           <td className="border border-gray-300 px-2 py-1">
//     //             {row.updater}
//     //           </td>
//     //         </tr>
//     //       ))}
//     //     </tbody>
//     //   </table>
//     // </div>
//     <div className="bg-[#fafaf6] h-screen border border-[#fafaf6]">
//       <div className="screen-size m-9 ">
//         <Link to="/timeSheet" className="text-[#0033ffe2]">
//           Back
//         </Link>
//         <p className="text-xl font-medium py-6">View Summary</p>
//         {/* Original */}
//         <div className="flex  justify-between items-center w-full">
//           <div className="flex justify-start gap-4 ">
//             <div className="relative grid grid-cols-1 ">
//               <label className="text_size_6">Start Date</label>
//               {/* <br /> */}
//               <input
//                 type="date"
//                 className="border border-[#D9D9D9] rounded outline-none p-2 text-[#000000] text-sm"
//                 onChange={(e) => setStartDate(e.target.value)}
//               />
//             </div>
//             <div className="relative grid grid-cols-1">
//               <label className="text_size_6">End Date</label>
//               {/* <br /> */}
//               <input
//                 type="date"
//                 className="border border-[#D9D9D9] rounded outline-none p-2 text-[#000000] text-sm"
//                 onChange={(e) => setEndDate(e.target.value)}
//               />
//             </div>
//           </div>
//           <div className="flex justify-end gap-4 mt-6">
//             <div className="relative grid grid-cols-1 ">
//               <input
//                 value={categoryFilter}
//                 placeholder="Select type"
//                 className="border border-[#D9D9D9] cursor-pointer rounded outline-none p-2 text-[#000000] text-sm"
//                 onClick={() => {
//                   setToggleClick(!toggleClick);
//                 }}
//                 readOnly
//               />
//               <span className="absolute right-2 top-2">
//                 <FaAngleDown className="text-xl text-dark_grey" />
//               </span>
//               {toggleClick && (
//                 <div
//                   className="absolute border top-10 border-[#D9D9D9] mt-1 w-full text-[15px] text-dark_grey p-1 bg-white z-50"
//                   onClick={() => {
//                     setToggleClick(false);
//                   }}
//                 >
//                   {["Offshore", "HO", "SBW", "ORMC", "BLNG"].map((category) => (
//                     <p
//                       key={category}
//                       className="hover:bg-secondary hover:text-white p-1 cursor-pointer"
//                       onClick={() => {
//                         handleCategorySelect(category);
//                         setLoading(!loading);
//                       }}
//                     >
//                       {category}
//                     </p>
//                   ))}
//                 </div>
//               )}
//             </div>
//             <SearchBoxForTimeSheet placeholder="Employee Id" />
//             <FilterForTimeSheet />
//           </div>
//         </div>

//         {/* {!loading && (
//         <VTimeSheetTable
//           AllFieldData={AllFieldData}
//           categoryFilter={categoryFilter}
//           data={data}
//         />
//       )} */}
//         <div className="overflow-x-auto pt-5">
//           <table className="table-auto border-collapse border border-gray-300 w-full text-sm text-left">
//             <thead>
//               <tr className="bg-grey text-white">
//                 <th className="border border-grey px-2 py-1">Employee Name</th>
//                 <th className="border border-grey px-2 py-1">Project</th>
//                 <th className="border border-grey px-2 py-1">21</th>
//                 <th className="border border-grey px-2 py-1">22</th>
//                 <th className="border border-grey px-2 py-1">23</th>
//                 <th className="border border-grey px-2 py-1">24</th>
//                 <th className="border border-grey px-2 py-1">25</th>
//                 <th className="border border-grey px-2 py-1">26</th>
//                 <th className="border border-grey px-2 py-1">27</th>
//                 <th className="border border-grey px-2 py-1">28</th>
//                 <th className="border border-grey px-2 py-1">29</th>
//                 <th className="border border-grey px-2 py-1">30</th>
//                 <th className="border border-grey px-2 py-1">31</th>
//                 <th className="border border-grey px-2 py-1">1</th>
//                 <th className="border border-grey px-2 py-1">2</th>
//                 <th className="border border-grey px-2 py-1">3</th>
//                 <th className="border border-grey px-2 py-1">4</th>
//                 <th className="border border-grey px-2 py-1">5</th>
//                 <th className="border border-grey px-2 py-1">6</th>
//                 <th className="border border-grey px-2 py-1">7</th>
//                 <th className="border border-grey px-2 py-1">8</th>
//                 <th className="border border-grey px-2 py-1">9</th>
//                 <th className="border border-grey px-2 py-1">10</th>
//                 <th className="border border-grey px-2 py-1">11</th>
//                 <th className="border border-grey px-2 py-1">12</th>
//                 <th className="border border-grey px-2 py-1">13</th>
//                 <th className="border border-grey px-2 py-1">14</th>
//                 <th className="border border-grey px-2 py-1">15</th>
//                 <th className="border border-grey px-2 py-1">16</th>
//                 <th className="border border-grey px-2 py-1">17</th>
//                 <th className="border border-grey px-2 py-1">18</th>
//                 <th className="border border-grey px-2 py-1">19</th>
//                 <th className="border border-grey px-2 py-1">20</th>
//                 <th className="border border-grey px-2 py-1">NH</th>
//                 <th className="border border-grey px-2 py-1">ND</th>
//                 <th className="border border-grey px-2 py-1">PH</th>
//                 <th className="border border-grey px-2 py-1">PH-D</th>
//                 <th className="border border-grey px-2 py-1">AL/CL</th>
//                 <th className="border border-grey px-2 py-1">SL</th>
//                 <th className="border border-grey px-2 py-1">OFF</th>
//                 <th className="border border-grey px-2 py-1">A</th>
//                 <th className="border border-grey px-2 py-1">UAL</th>
//                 <th className="border border-grey px-2 py-1">OT</th>
//                 <th className="border border-grey px-2 py-1">Verified</th>
//                 <th className="border border-grey px-2 py-1">Updater</th>
//               </tr>
//             </thead>
//             <tbody>
//               {data.map((row, index) => (
//                 <tr
//                   key={index}
//                   className={index % 2 === 0 ? "bg-white" : "bg-white"}
//                 >
//                   <td className="border border-grey px-2 py-1">{row.name}</td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.project}
//                   </td>

//                   <td className="border border-grey px-2 py-1">
//                     {row.total.NH}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.ND}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.PH}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.OT}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.PH}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.OT}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.PH}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.OT}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.PH}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.OT}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.PH}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.OT}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.PH}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.OT}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.PH}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.OT}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.PH}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.OT}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.PH}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.OT}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.PH}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.OT}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.PH}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.OT}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.PH}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.OT}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.PH}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.OT}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.PH}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.OT}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.PH}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.OT}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.PH}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.OT}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.OT}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.PH}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.OT}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.PH}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.OT}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.PH}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.total.OT}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.verified}
//                   </td>
//                   <td className="border border-grey px-2 py-1">
//                     {row.updater}
//                   </td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         </div>
//       </div>
//     </div>
//   );
// };

const client = generateClient();
export const ViewSummary = () => {
  const [data, setData] = useState(null);
  const [secondaryData, setSecondaryData] = useState(null);
  const [loading, setLoading] = useState(true);
  const { convertedStringToArrayObj, getPosition } = useFetchData("Offshore");

  useEffect(() => {
    // if (!convertedStringToArrayObj) return;

    const fetchData = async () => {
      setLoading(true);
      try {
        const processedData = convertedStringToArrayObj.map((value) =>
          value[1]?.flat()
        );
        // id: value[0]?.id,

        // .filter((item) => item?.length > 0);
        console.log(processedData.flat());

        setData(processedData);
        setSecondaryData(processedData);
      } catch (error) {
        console.error("Error processing data", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [convertedStringToArrayObj]);
  // useEffect(() => {
  //   //   setTimeout(() => {
  //   const fetchData = async () => {
  //     const [empPersonalInfos, empPersonalDocs, leaveStatus] =
  //       await Promise.all([
  //         client.graphql({ query: listEmpPersonalInfos }),
  //         client.graphql({ query: listEmpWorkInfos }),
  //         client.graphql({ query: listLeaveStatuses }),
  //       ]);
  //     const candidates = empPersonalInfos?.data?.listEmpPersonalInfos?.items;
  //     const interviews = empPersonalDocs?.data?.listEmpWorkInfos?.items;

  //     const leaveStatusData = leaveStatus?.data?.listLeaveStatuses?.items;

  //     const mergedData = candidates
  //       .map((candidate) => {
  //         const interviewDetails = interviews.find(
  //           (item) => item.empID === candidate.empID
  //         );
  //         const leaveStatusDetails = leaveStatusData.find(
  //           (item) => item.empID === candidate.empID
  //         );

  //         // Return null if all details are undefined
  //         if (!interviewDetails && !leaveStatusDetails) {
  //           return null;
  //         }

  //         return {
  //           ...candidate,
  //           ...interviewDetails,
  //           ...leaveStatusDetails,
  //         };
  //       })
  //       .filter((item) => item !== null && item !== undefined);
  //     console.log(mergedData);
  //   };
  //   fetchData();
  //   //   }, 5000);
  // }, []);

  const employees = [
    {
      name: "ABDUL AZIM BIN A.S. NARODIN",
      project: "50***F10",
      hoursPerDay: [
        12,
        12,
        12,
        12,
        12,
        12,
        12,
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        12,
        12,
        12,
        12,
        "",
        "",
        "",
        "",
        "",
      ],
      ot: [
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        0,
        3,
        3,
        0,
        0,
        0,
        3,
        0,
        0,
      ],
      nh: "84",
      nd: "7",
      ph: "0",
      ph_d: "0",
      al_cl: "0",
      sl: "0",
      off: "0",
      a: "0",
      ual: "0",
      ot_total: "3",
      verified: "YES",
      updater: "ROZATUL AZRNIE BINTI SANIF",
    },
    {
      name: "AHMAD SHAHIZAN BIN HAINI",
      project: "50***F10",
      hoursPerDay: [
        12,
        12,
        12,
        12,
        12,
        12,
        12,
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        12,
        12,
        12,
        12,
        "",
        "",
        "",
        "",
        "",
      ],
      ot: [
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        0,
        3,
        3,
        0,
        0,
        0,
        3,
        0,
        0,
      ],
      nh: "84",
      nd: "7",
      ph: "0",
      ph_d: "0",
      al_cl: "0",
      sl: "0",
      off: "0",
      a: "0",
      ual: "0",
      ot_total: "3",
      verified: "YES",
      updater: "ROZATUL AZRNIE BINTI SANIF",
    },
    {
      name: "DANSON SAIT ANAK MAWAN",
      project: "585***F50",
      hoursPerDay: [
        12,
        12,
        12,
        12,
        12,
        12,
        12,
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        12,
        12,
        12,
        12,
        "",
        "",
        "",
        "",
        "",
      ],
      ot: [
        3,
        3,
        3,
        0,
        0,
        0,
        0,
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        0,
        3,
        3,
        0,
        0,
        0,
        3,
        0,
        0,
      ],
      nh: "132",
      nd: "11",
      ph: "0",
      ph_d: "0",
      al_cl: "0",
      sl: "0",
      off: "0",
      a: "0",
      ual: "0",
      ot_total: "15",
      verified: "YES",
      updater: "ROZATUL AZRNIE BINTI SANIF",
    },
    {
      name: "IRUDAYA NATHAN ANTONY SEKAR",
      project: "585***F50",
      hoursPerDay: [
        12,
        12,
        12,
        12,
        12,
        12,
        12,
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        12,
        12,
        12,
        12,
        "",
        "",
        "",
        "",
        "",
      ],
      ot: [
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        0,
        3,
        3,
        0,
        0,
        0,
        3,
        0,
        0,
      ],
      nh: "120",
      nd: "10",
      ph: "0",
      ph_d: "0",
      al_cl: "0",
      sl: "0",
      off: "0",
      a: "0",
      ual: "0",
      ot_total: "12",
      verified: "YES",
      updater: "ROZATUL AZRNIE BINTI SANIF",
    },
  ];

  return (
    <div className="overflow-x-auto p-4">
      <table className="min-w-full border-collapse border border-gray-400 text-sm">
        <thead>
          <tr>
            <th className="border border-gray-400 px-2 py-1" rowSpan="2">
              Employee Name
            </th>
            <th className="border border-gray-400 px-2 py-1" rowSpan="2">
              Project
            </th>
            {Array.from({ length: 31 }, (_, i) => (
              <th className="border border-gray-400 px-2 py-1" key={i}>
                {i + 1}
              </th>
            ))}
            <th className="border border-gray-400 px-2 py-1">NH</th>
            <th className="border border-gray-400 px-2 py-1">ND</th>
            <th className="border border-gray-400 px-2 py-1">PH</th>
            <th className="border border-gray-400 px-2 py-1">PH-D</th>
            <th className="border border-gray-400 px-2 py-1">AL/CL</th>
            <th className="border border-gray-400 px-2 py-1">SL</th>
            <th className="border border-gray-400 px-2 py-1">OFF</th>
            <th className="border border-gray-400 px-2 py-1">A</th>
            <th className="border border-gray-400 px-2 py-1">UAL</th>
            <th className="border border-gray-400 px-2 py-1">OT</th>
            <th className="border border-gray-400 px-2 py-1">Verified</th>
            <th className="border border-gray-400 px-2 py-1">Updater</th>
          </tr>
        </thead>
        <tbody>
          {employees.map((employee, index) => {
            // Calculate totals for each employee
            const totalHours = employee.hoursPerDay.reduce(
              (acc, hour) => acc + (hour || 0),
              0
            );
            const totalOT = employee.ot.reduce((acc, ot) => acc + (ot || 0), 0);

            return (
              <>
                <tr key={index}>
                  {/* Employee Info */}
                  <td className="border border-gray-400 px-2 py-1" rowSpan="2">
                    {employee.name}
                  </td>
                  <td className="border border-gray-400 px-2 py-1" rowSpan="2">
                    {employee.project}
                  </td>

                  {/* Hours/Day Row */}
                  {employee.hoursPerDay.map((hour, i) => (
                    <td
                      key={`hour-${index}-${i}`}
                      className={`border border-gray-400 px-2 py-1 ${
                        hour !== "" ? "bg-green-200" : ""
                      }`}
                    >
                      {hour}
                    </td>
                  ))}

                  {/* Merged Columns */}
                  <td className="border border-gray-400 px-2 py-1" rowSpan="2">
                    {employee.nh}
                  </td>
                  <td className="border border-gray-400 px-2 py-1" rowSpan="2">
                    {employee.nd}
                  </td>
                  <td className="border border-gray-400 px-2 py-1" rowSpan="2">
                    {employee.ph}
                  </td>
                  <td className="border border-gray-400 px-2 py-1" rowSpan="2">
                    {employee.ph_d}
                  </td>
                  <td className="border border-gray-400 px-2 py-1" rowSpan="2">
                    {employee.al_cl}
                  </td>
                  <td className="border border-gray-400 px-2 py-1" rowSpan="2">
                    {employee.sl}
                  </td>
                  <td className="border border-gray-400 px-2 py-1" rowSpan="2">
                    {employee.off}
                  </td>
                  <td className="border border-gray-400 px-2 py-1" rowSpan="2">
                    {employee.a}
                  </td>
                  <td className="border border-gray-400 px-2 py-1" rowSpan="2">
                    {employee.ual}
                  </td>
                  <td className="border border-gray-400 px-2 py-1" rowSpan="2">
                    {employee.ot_total}
                  </td>
                  <td className="border border-gray-400 px-2 py-1" rowSpan="2">
                    {employee.verified}
                  </td>
                  <td className="border border-gray-400 px-2 py-1" rowSpan="2">
                    {employee.updater}
                  </td>
                </tr>

                {/* OT Row */}
                <tr>
                  {employee.ot.map((ot, i) => (
                    <td
                      key={`ot-${index}-${i}`}
                      className={`border border-gray-400 px-2 py-1 ${
                        ot !== "" ? "bg-yellow-200" : ""
                      }`}
                    >
                      {ot}
                    </td>
                  ))}
                </tr>

                {/* Total Row */}
                <tr>
                  <td className="border border-gray-400 px-2 py-1" colSpan={2}>
                    Total
                  </td>
                  {employee.hoursPerDay.map((hour, i) => (
                    <td
                      key={`total-hour-${index}-${i}`}
                      className="border border-gray-400 px-2 py-1"
                    >
                      {hour}
                    </td>
                  ))}
                  <td className="border border-gray-400 px-2 py-1">
                    {totalHours}
                  </td>
                  <td className="border border-gray-400 px-2 py-1">
                    {employee.nd}
                  </td>
                  <td className="border border-gray-400 px-2 py-1">
                    {employee.ph}
                  </td>
                  <td className="border border-gray-400 px-2 py-1">
                    {employee.ph_d}
                  </td>
                  <td className="border border-gray-400 px-2 py-1">
                    {employee.al_cl}
                  </td>
                  <td className="border border-gray-400 px-2 py-1">
                    {employee.sl}
                  </td>
                  <td className="border border-gray-400 px-2 py-1">
                    {employee.off}
                  </td>
                  <td className="border border-gray-400 px-2 py-1">
                    {employee.a}
                  </td>
                  <td className="border border-gray-400 px-2 py-1">
                    {employee.ual}
                  </td>
                  <td className="border border-gray-400 px-2 py-1">
                    {totalOT}
                  </td>
                  <td className="border border-gray-400 px-2 py-1">-</td>
                  <td className="border border-gray-400 px-2 py-1">-</td>
                </tr>
              </>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};
