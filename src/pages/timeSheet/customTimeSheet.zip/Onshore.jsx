import { TimeSheetBrowser } from "../../utils/TimeSheetBrowser"


export const Onshore = () => {
  return (
    <div>
      <TimeSheetBrowser title="OnShore" />
    </div>
  )
}
