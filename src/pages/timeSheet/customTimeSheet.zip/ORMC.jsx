import { TimeSheetBrowser } from "../../utils/TimeSheetBrowser";

export const ORMC = () => {
  return (
    <div>
      <TimeSheetBrowser title="ORMC" />
    </div>
  );
};
