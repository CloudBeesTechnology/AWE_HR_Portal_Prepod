import { TimeSheetBrowser } from "../../utils/TimeSheetBrowser";

export const SBW = () => {
  return (
    <div>
      <TimeSheetBrowser title="SBW" />
    </div>
  );
};
