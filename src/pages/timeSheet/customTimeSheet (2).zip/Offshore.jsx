
import { TimeSheetBrowser } from "../../utils/TimeSheetBrowser";

export const Offshore = () => {
  return (
  <div>
    <TimeSheetBrowser title="Offshore" />
  </div>
  );
};
