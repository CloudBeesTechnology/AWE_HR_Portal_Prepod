import { TimeSheetBrowser } from "../../utils/TimeSheetBrowser";

export const Blng = () => {
  return (
    <section>
      <TimeSheetBrowser title="BLNG" />
    </section>
  );
};
