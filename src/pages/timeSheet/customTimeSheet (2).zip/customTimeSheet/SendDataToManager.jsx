import { useState, useEffect } from 'react';
import { generateClient } from "@aws-amplify/api";
import {
  listEmpPersonalInfos,
  listEmpWorkInfos,
  listUsers,
} from "../../../graphql/queries";

// Create client instance
const client = generateClient();

export const useSendDataToManager = async (filterPending) => {
  try {
    const loginAuth = localStorage.getItem("userID")?.toUpperCase();

    const fetchData = async () => {
      const [empPersonalInfos, empPersonalDocs, userDetails] =
        await Promise.all([
          client.graphql({ query: listEmpPersonalInfos }),
          client.graphql({ query: listEmpWorkInfos }),
          client.graphql({ query: listUsers }),
        ]);

      const candidates = empPersonalInfos?.data?.listEmpPersonalInfos?.items;
      const interviews = empPersonalDocs?.data?.listEmpWorkInfos?.items;
      const usersData = userDetails?.data?.listUsers?.items;

      const mergedData = candidates
        .map((candidate) => {
          const interviewDetails = interviews.find(
            (item) => item.empID === candidate.empID
          );

          const allUser = usersData.find(
            (item) => item.empID === candidate.empID
          );

          if (!interviewDetails && !allUser) {
            return null;
          }

          return {
            ...candidate,
            ...interviewDetails,
            ...allUser,
          };
        })
        .filter((item) => item !== null);

      const filterManager = mergedData.filter((fil) => fil.sapNo === "790");

      const filterdData = mergedData.filter(
        (value) => value.empID === loginAuth && value.selectType === "Manager"
      );
      return filterdData;
    };
    
    return await fetchData();
  } catch (err) {
    console.error("Error fetching manager data:", err);
  }
};
