import { TimeSheetBrowser } from "../../utils/TimeSheetBrowser";

export const HO = () => {
  return (
    <div>
      <TimeSheetBrowser title="HO" />
    </div>
  );
};
