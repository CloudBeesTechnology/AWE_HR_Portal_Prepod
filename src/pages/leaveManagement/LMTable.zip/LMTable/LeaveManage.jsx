import { useEffect, useState } from "react";
import { LMTable } from "./LMTable";
import { HOLTable } from "./HOLTable";
import { ELBDetails } from "./ELBDetails";
import { HOLDetails } from "./HOLDetails";
import { LMDetails } from "./LMDetails";
import { Filter } from "./Filter";
import { Pagination } from "./Pagination";
import { IoSearch } from "react-icons/io5";
import { FilterMonthAndYear } from "./FilterMonthAndYear";
import { ViewForm } from "./ViewForm";
import { EmpLeaveBalance } from "./EmpLeaveBalance";
import { SearchBox } from "./Searchbox";

export const LeaveManage = () => {
  const [data, setData] = useState(LMDetails);
  const [count, setCount] = useState(0);
  const [filterStatus, setFilterStatus] = useState("All");
  const [selectedMonth, setSelectedMonth] = useState('');
  const [selectedYear, setSelectedYear] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(15);
  const [searchTerm, setSearchTerm] = useState('');
  const [toggleClick, setToggleClick] = useState(false);
  const [selectedLeaveData, setSelectedLeaveData] = useState(null);

  const getData = () => {
    if (count === 0) return LMDetails;
    if (count === 1) return HOLDetails;
    if (count === 2) return ELBDetails;
  };

  const applyFilters = () => {
    let filteredData = getData();

    if (filterStatus !== "All") {
      filteredData = filteredData.filter(item => item.status === filterStatus);
    }
    if (selectedMonth) {
      filteredData = filteredData.filter(item => {
        const itemDate = new Date(item["received Date"]);
        return itemDate.getMonth() + 1 === parseInt(selectedMonth);
      });
    }
    if (selectedYear) {
      filteredData = filteredData.filter(item => {
        const itemDate = new Date(item["received Date"]);
        return itemDate.getFullYear() === parseInt(selectedYear);
      });
    }
    if (searchTerm) {
      filteredData = filteredData.filter(item =>
        item.empID.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    return filteredData;
  };

  useEffect(() => {
    const filteredData = applyFilters();
    const startIndex = (currentPage - 1) * rowsPerPage;
    const paginatedData = filteredData.slice(startIndex, startIndex + rowsPerPage);
    setData(paginatedData);
  }, [currentPage, filterStatus, selectedMonth, selectedYear, rowsPerPage, searchTerm, count]);

  const handleFilterChange = (status) => {
    setFilterStatus(status);
    setCurrentPage(1);
  };

  const handleDateChange = (month, year) => {
    setSelectedMonth(month);
    setSelectedYear(year);
    setCurrentPage(1);
  };

  const handleSearchChange = (term) => {
    setSearchTerm(term);
    setCurrentPage(1);
  };

  const handleClickForToggle = () => {
    setToggleClick(!toggleClick);
  };

  const handleLimitChange = (e) => {
    setRowsPerPage(parseInt(e.target.value));
    setCurrentPage(1);
  };

  const emptySearch = () => {
    setSearchTerm('');
    setData(applyFilters());
  };

  const totalPages = Math.ceil(applyFilters().length / rowsPerPage);

  const handleViewClick = (leaveData) => {
    setSelectedLeaveData(leaveData);
    setToggleClick(true); 
  };

  const handleUpdate = (empID, newStatus, remark) => {
    setData((prevData) =>
      prevData.map((item) =>
        item.empID === empID
          ? { ...item, status: newStatus, remark: remark } 
          : item
      )
    );
    setSelectedLeaveData(null); 
    setToggleClick(false); 
  };

  return (
    <section className={`py-20 px-10`}>
      <div className="screen-size">
        <section className="flex justify-between items-center py-3">
          <p className="text_size_5">
            <span
              className={`relative after:absolute after:-bottom-2 after:left-0 after:w-full after:h-1 cursor-pointer ${count === 0 && "after:bg-primary"}`}
              onClick={() => {
                setCount(0); 
                setCurrentPage(1); 
              }}
            >
              Request Leave
            </span>{" "} / {" "}
            <span
              className={`relative after:absolute after:-bottom-2 after:left-0 after:w-full after:h-1 cursor-pointer ${count === 1 && "after:bg-primary"}`}
              onClick={() => {
                setCount(1); 
                setCurrentPage(1); 
              }}
            >
              History of leave
            </span>{" "} / {" "}
            <span
              className={`relative after:absolute after:-bottom-2 after:left-0 after:w-full after:h-1 cursor-pointer ${count === 2 && "after:bg-primary"}`}
              onClick={() => {
                setCount(2); 
                setCurrentPage(1); 
              }}
            >
              Employee Leave Balance
            </span>
          </p>

          <div className={`flex gap-5 w-[600px] ${count === 2 ? "justify-end" : ""}`}>
            <SearchBox
              newFormData={LMDetails}
              searchIcon2={<IoSearch />}
              placeholder="Employee ID"
              emptySearch={emptySearch}
              onSearchChange={handleSearchChange}
            />
            {count !== 2 && (
              <>
                <FilterMonthAndYear onDateChange={handleDateChange} />
                <Filter AfterFilter={handleFilterChange} />
              </>
            )}
          </div>
        </section>
        <section className="center w-full">
          {count === 0 && (
            <LMTable 
              handleClickForToggle={handleClickForToggle} 
              initialData={data} 
              onViewClick={handleViewClick} 
            />
          )}
          {count === 1 && <HOLTable initialData={LMDetails} />}
          {count === 2 && <EmpLeaveBalance initialData={LMDetails} />}
        </section>
        <section className="my-10 flex justify-between items-center">
          <div className="flex-1 ">
            {/* <div className="relative">
            
              <select
                value={rowsPerPage}
                onChange={handleLimitChange}
                className="border border-[#5A5858] text-sm font-semibold text-dark_grey rounded-lg p-2 flex gap-2 items-center"
                readOnly
                disabled
              >
                <option value={20}>20 show</option>
              </select> 
            </div> */}
          </div>
          <div className="flex-1 flex justify-end">
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={(newPage) => {
                if (newPage >= 1 && newPage <= totalPages) {
                  setCurrentPage(newPage);
                }
              }}
            />
          </div>
        </section>
      </div>
      {toggleClick && selectedLeaveData && (
        <ViewForm 
          handleClickForToggle={handleClickForToggle} 
          leaveData={selectedLeaveData} 
          onUpdate={handleUpdate} 
        />
      )}
    </section>
  );
};
