import React, { useEffect, useState } from "react";

export const LMTable = ({
  initialData,
  statusUpdate,
  handleClickForToggle,
  onViewClick
}) => {
  const [data, setData] = useState(initialData);

  useEffect(() => {
    setData(initialData);
  }, [initialData]);
  const heading = [
    "Employee ID",
    "Name",
    "Received Date",
    "Superior Name",
    "Approved Date",
    "Manager Name",
    "Approved Date",
    "Submitted Form",
    "Status",
  ];

  const editStatus = (allItem, status) => {
    statusUpdate(allItem, status);
  };
  return (
    <div className="overflow-x-auto">
      <table className="w-full ">
        <thead className="bg-black">
          <tr className="  bg-[#C5C5C5]  rounded-sm">
            {heading.map((header, index) => (
              <th key={index} className=" px-4 py-5 text-[15px] text-secondary">
                {header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data &&
            data.map((item, index) => {
              return (
                <tr
                  key={index}
                  className="text-center text-sm border-b-2 border-[#CECECE]"
                >
                  <td className="border-b-2 border-[#CECECE] py-3">
                    {item.empID}
                  </td>
                  <td className="border-b-2 border-[#CECECE] text-start pl-4">
                    {item.name}
                  </td>
                  <td className="border-b-2 border-[#CECECE]">
                    {item["received Date"]}
                  </td>
                  <td className="border-b-2 border-[#CECECE]">
                    {item["superior Name"]}
                  </td>
                  <td className="border-b-2 border-[#CECECE]">
                    {item["approved Date"]}
                  </td>
                  <td className="border-b-2 border-[#CECECE]">
                    {item["manager Name"]}
                  </td>
                  <td className="border-b-2 border-[#CECECE]">
                    {item["manager Approved Date"]}
                  </td>

                  <td className="border-b-2 border-[#CECECE] cursor-pointer">
                    <span
                      className="border-b-2 border-dark_grey "
                      onClick={() => {
                        handleClickForToggle();
                        onViewClick(item)
                      }}
                    >
                      {item["submitted Form"]}
                    </span>
                  </td>

                  <td
                    className={`border-b-2 border-[#CECECE] ${item.status === "Rejected"
                      ? "text-[#C50000]"
                      : item.status === "Approved"
                        ? "text-[#0CB100]"
                        : item.status === "Pending"
                          ? "text-dark_grey"
                          : ""
                      }`}
                  >
                    {item.status}
                  </td>

                </tr>
              );
            })}
        </tbody>
      </table>
    </div>
  );
};
