import React, { useState } from "react";
import { RxCross2 } from "react-icons/rx";

export const ViewForm = ({ handleClickForToggle, leaveData, onUpdate }) => {
  const [remark, setRemark] = useState('');

  const handleApprove = () => {
    onUpdate(leaveData.empID, "Approved", remark);
  };

  const handleReject = () => {
    onUpdate(leaveData.empID, "Rejected", remark);
  };

  const getStatusClass = (status) => {
    switch (status) {
      case "Approved":
        return "bg-[#0CB100]"; 
      case "Rejected":
        return "bg-[#C50000]"; 
      case "Pending":
        return "bg-yellow-400"; 
      default:
        return ""; 
    }
  };

  return (
    <main className="flex flex-col items-center justify-center inset-0 z-50 fixed">
      <header className="w-[500px] mt-5 ">
        <div className="flex justify-between bg-[#C6C6C6] py-1">
          <p></p>
          <p className="text-dark_grey text-[24px] font-medium">View Form</p>
          <RxCross2
            className="text-2xl mt-2 mr-4 cursor-pointer"
            onClick={handleClickForToggle}
          />
        </div>
      </header>
      <section className="shadow-md w-[500px] px-5 bg-white">
        <div className="p-5 text_size_6 ">
          <div className="grid grid-cols-2 ">
            <p>Name</p>
            <p>{leaveData.name}</p>
          </div>
          <div className="grid grid-cols-2 pt-1">
            <p>Job Title</p>
            <p>{leaveData.jobTitle}</p>
          </div>
          <div className="grid grid-cols-2 pt-1">
            <p>Badge</p>
            <p>{leaveData.badge}</p>
          </div>
          <div className="grid grid-cols-2 pt-1">
            <p>Dept/Dev</p>
            <p>{leaveData.deptDev}</p>
          </div>
          <div className="grid grid-cols-2 pt-1">
            <p>Select Date</p>
            <p>{leaveData.selectDate}</p>
          </div>
          <div className="grid grid-cols-2 pt-1">
            <p>Leave Type</p>
            <p>{leaveData["leave Type"]}</p>
          </div>
          <div className="grid grid-cols-2 pt-1">
            <p>Apply to</p>
            <p>{leaveData["start Date"]} to {leaveData["end Date"]}</p>
          </div>
          <div className="grid grid-cols-2 pt-1">
            <p>No of days</p>
            <p>{leaveData["no of days"]}</p>
          </div>
          <div className="grid grid-cols-2 pt-1">
            <p>Reason</p>
            <p>{leaveData.reason}</p>
          </div>
          
          {/* Conditionally render remark input and buttons */}
          {leaveData.status === "Pending" ? (
            <>
              <div className="grid grid-rows-2 pt-1">
                <label htmlFor="remark">Remark :</label>
                <input
                  type="text"
                  value={remark}
                  onChange={(e) => setRemark(e.target.value)}
                  className="border border-grey w-full h-9 outline-none pl-2"
                />
              </div>
            </>
          ) : (
            <div className="mt-8 flex items-center flex-col pt-1">
              <p className={`p-2 px-3 rounded text-dark_grey text_size_6 ${getStatusClass(leaveData.status)}`}>
                <strong>Status:</strong> {leaveData.status}</p>
                {leaveData.remark && (
                  <p className="p-2 px-3 rounded text-dark_grey text_size_6 "><strong>Remark:</strong> {leaveData.remark || "No remarks added"}</p>
                )} 
            </div>
          )}
        </div>
        <div className="flex justify-between px-5 pb-10">
          {leaveData.status === "Pending" && (
            <>
              <button 
                className="bg-[#FEF116] p-2 px-3 rounded text-dark_grey text_size_6"
                onClick={handleApprove}
              >
                Approved
              </button>
              <button 
                className="border border-grey p-2 px-5 rounded text-dark_grey text_size_6"
                onClick={handleReject}
              >
                Reject
              </button>
            </>
          )}
        </div>
      </section>
    </main>
  );
};
