import React from 'react';
import { FaArrowLeft } from "react-icons/fa6";
import { FaArrowRight } from "react-icons/fa";

export const Pagination = ({ currentPage, totalPages, onPageChange }) => {
  
  const getDisplayedPages = () => {
    const pages = [];
    
    // Always display the first 3 pages (1, 2, 3)
    pages.push(1);
    if (totalPages > 1) pages.push(2);
    if (totalPages > 2) pages.push(3);
    
    // The fourth page should dynamically update based on the current page
    if (totalPages > 3) {
      // If the currentPage is 4 or higher, show it as the fourth page
      const lastPage = currentPage > 3 ? currentPage : 4;
      if (lastPage <= totalPages) pages.push(lastPage);
    }

    return pages;
  }; 

  const displayedPages = getDisplayedPages();

  return (
    <div className="flex justify-between w-3/5 items-center">
   
      <button
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage === 1}  
        className="flex items-center gap-2 border border-[#5A5858] text-sm text-dark_grey rounded-lg  px-5 py-2 rounded-lg hover:bg-gray-200 px-5 py-2 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors duration-200"
      >
        <FaArrowLeft className="text-[16px]" />
        <span>Previous</span>
      </button>

  
      {displayedPages.map((page, index) => (
        <button
          key={index}
          onClick={() => onPageChange(page)}
          className={`w-8 h-8 flex items-center justify-around text-sm font-medium rounded-full ${currentPage === page ? 'bg-indigo-600 text-white shadow-md' : 'bg-gray-200 text-gray-600'} hover:bg-indigo-500 hover:text-white transition-colors duration-200`}
        >
          {page}
        </button>
      ))}

      <button
        onClick={() => onPageChange(currentPage + 1)}
        disabled={currentPage === totalPages}
        className="flex items-center gap-2 border border-[#5A5858] text-sm text-dark_grey rounded-lg  px-5 py-2 rounded-lg px-5 py-2 hover:bg-gray-200 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors duration-200"
      >
        <span>Next</span>
        <FaArrowRight className="text-[16px]" />
      </button>
    </div>
  );
};


