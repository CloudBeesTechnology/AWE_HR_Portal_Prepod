import React from 'react';

export const SearchBox = ({ onSearchChange, placeholder, searchIcon2, }) => {
  const handleChange = (event) => {
    onSearchChange(event.target.value);
  };

  return (
    
      <div className="relative w-3/5">
        <div className='py-2 w-full text_size_5 bg-white border text-grey border-lite_grey rounded-xl flex items-center px-5 gap-2'>
          <input
            type="text"
            placeholder={placeholder}
            onChange={handleChange}
            className="outline-none w-full"
          />
          <div className=''>{searchIcon2}</div>
        </div>
      </div>
  );
};
