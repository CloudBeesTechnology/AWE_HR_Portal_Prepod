import React, { useEffect, useState } from "react";
import { IoFilterOutline } from "react-icons/io5";

export const Filter = ({ AfterFilter }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("All");

  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };

  const handleFilterChange = (category) => {
    setSelectedCategory(category);
    setIsOpen(false);
  };

  useEffect(() => {
    AfterFilter(selectedCategory);
  }, [selectedCategory]);

  return (
    <section className="relative w-auto">
      <div className="p-2 flex items-center gap-4 border rounded-lg p-2 border-[#CDCDCD] cursor-pointer" onClick={toggleDropdown}>
        <IoFilterOutline className="" />
        <p className="">Filter</p>
      </div>
      {isOpen && (
        <div className="absolute top-full right-2 w-full md:w-32 shadow-lg bg-white z-50">
          <div className="py-1 shadow-md flex flex-col bg-white">
            <button onClick={() => handleFilterChange("All")} className="w-full p-2 border rounded-md text-xs font-bold text-dark_grey hover:bg-lite_grey hover:text-white">
              All
            </button>
            <button onClick={() => handleFilterChange("Pending")} className="w-full p-2 border rounded-md text-xs font-bold text-dark_grey hover:bg-lite_grey hover:text-white">
              Pending
            </button>
            <button onClick={() => handleFilterChange("Approved")} className="w-full p-2 border rounded-md text-xs font-bold text-dark_grey hover:bg-lite_grey hover:text-white">
              Approved
            </button>
            <button onClick={() => handleFilterChange("Rejected")} className="w-full p-2 border rounded-md text-xs font-bold text-dark_grey hover:bg-lite_grey hover:text-white">
              Rejected
            </button>
          </div>
        </div>
      )}
    </section>
  );
};
