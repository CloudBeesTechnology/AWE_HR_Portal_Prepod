import React from "react";

export const HOLTable = ({ initialData }) => {
  const heading = [
    "Employee ID",
    "Leave Type",
    "Start Date",
    "End Date",
    "Reason",
    "Status",
  ];

  return (
    <table className="w-full">
      <thead className="bg-black">
        <tr className="bg-[#C5C5C5] rounded-sm">
          {heading.map((header, index) => (
            <th key={index} className="px-4 py-5 text-[15px] text-secondary">
              {header}
            </th>
          ))}
        </tr>
      </thead>

      <tbody>
        {initialData &&
          initialData.map((item, index) => {
            return (
              <tr
                key={index}
                className="text-center text-sm border-b-2 border-[#CECECE]"
              >
                <td className="border-b-2 border-[#CECECE] py-3">
                  {item.empID}
                </td>
                <td className="border-b-2 border-[#CECECE]">
                  {item["leave Type"]}
                </td>
                <td className="border-b-2 border-[#CECECE]">
                  {item["start Date"]}
                </td>
                <td className="border-b-2 border-[#CECECE]">
                  {item["end Date"]}
                </td>
                <td className="border-b-2 border-[#CECECE]">
                  {item.reason}
                </td>
                <td className={`border-b-2 border-[#CECECE]`}>
                  {item.status || "Approved"} 
                </td>
              </tr>
            );
          })}
      </tbody>
    </table>
  );
};
